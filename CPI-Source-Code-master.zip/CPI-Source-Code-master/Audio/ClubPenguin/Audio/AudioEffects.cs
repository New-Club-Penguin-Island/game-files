using System;
using Fabric;
using UnityEngine;

namespace ClubPenguin.Audio
{
	internal class AudioEffects : MonoBehaviour
	{
		[Serializable]
		public struct OnCollisionEntry
		{
			public string EventName;

			public float MinRelativeVelocity;

			public float MaxRelativeVelocity;
		}

		public OnCollisionEntry[] OnCollision = new OnCollisionEntry[0];

		private float minRelativeVelSq;

		public void OnCollisionEnter(Collision collision)
		{
			float sqrMagnitude = collision.relativeVelocity.sqrMagnitude;
			for (int i = 0; i < OnCollision.Length; i++)
			{
				if (sqrMagnitude >= OnCollision[i].MinRelativeVelocity * OnCollision[i].MinRelativeVelocity && sqrMagnitude < OnCollision[i].MaxRelativeVelocity * OnCollision[i].MaxRelativeVelocity)
				{
					EventManager.Instance.PostEvent(OnCollision[i].EventName, EventAction.PlaySound, base.gameObject);
					break;
				}
			}
		}
	}
}
