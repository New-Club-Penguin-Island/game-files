using System.Collections;
using Disney.Kelowna.Common.Tests;

namespace ClubPenguin.BlobShadows.Tests
{
	public class BlobShadowsLoadingTest : BaseIntegrationTest
	{
		protected override IEnumerator runTest()
		{
			yield return null;
		}
	}
}
