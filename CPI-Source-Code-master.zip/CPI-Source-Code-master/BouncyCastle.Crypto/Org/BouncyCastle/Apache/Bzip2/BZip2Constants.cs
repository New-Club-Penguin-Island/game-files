using System;
using System.Runtime.CompilerServices;

namespace Org.BouncyCastle.Apache.Bzip2
{
	public class BZip2Constants
	{
		public const int baseBlockSize = 100000;

		public const int MAX_ALPHA_SIZE = 258;

		public const int MAX_CODE_LEN = 23;

		public const int RUNA = 0;

		public const int RUNB = 1;

		public const int N_GROUPS = 6;

		public const int G_SIZE = 50;

		public const int N_ITERS = 4;

		public const int MAX_SELECTORS = 18002;

		public const int NUM_OVERSHOOT_BYTES = 20;

		public static readonly int[] rNums;

		static BZip2Constants()
		{
			int[] array = new int[512];
			RuntimeHelpers.InitializeArray((global::System.Array)array, (RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/);
			rNums = array;
		}
	}
}
