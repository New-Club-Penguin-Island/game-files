using System;
using System.Runtime.CompilerServices;

namespace Org.BouncyCastle.Apache.Bzip2
{
	internal class CRC
	{
		public static readonly int[] crc32Table;

		internal int globalCrc;

		public CRC()
		{
			InitialiseCRC();
		}

		internal void InitialiseCRC()
		{
			globalCrc = -1;
		}

		internal int GetFinalCRC()
		{
			return ~globalCrc;
		}

		internal int GetGlobalCRC()
		{
			return globalCrc;
		}

		internal void SetGlobalCRC(int newCrc)
		{
			globalCrc = newCrc;
		}

		internal void UpdateCRC(int inCh)
		{
			int num = (globalCrc >> 24) ^ inCh;
			if (num < 0)
			{
				num = 256 + num;
			}
			globalCrc = (globalCrc << 8) ^ crc32Table[num];
		}

		static CRC()
		{
			int[] array = new int[256];
			RuntimeHelpers.InitializeArray((global::System.Array)array, (RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/);
			crc32Table = array;
		}
	}
}
