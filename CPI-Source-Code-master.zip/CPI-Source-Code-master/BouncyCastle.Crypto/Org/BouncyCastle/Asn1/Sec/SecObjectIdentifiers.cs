using Org.BouncyCastle.Asn1.X9;

namespace Org.BouncyCastle.Asn1.Sec
{
	public abstract class SecObjectIdentifiers
	{
		public static readonly DerObjectIdentifier EllipticCurve = new DerObjectIdentifier("1.3.132.0");

		public static readonly DerObjectIdentifier SecT163k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".1"));

		public static readonly DerObjectIdentifier SecT163r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".2"));

		public static readonly DerObjectIdentifier SecT239k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".3"));

		public static readonly DerObjectIdentifier SecT113r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".4"));

		public static readonly DerObjectIdentifier SecT113r2 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".5"));

		public static readonly DerObjectIdentifier SecP112r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".6"));

		public static readonly DerObjectIdentifier SecP112r2 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".7"));

		public static readonly DerObjectIdentifier SecP160r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".8"));

		public static readonly DerObjectIdentifier SecP160k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".9"));

		public static readonly DerObjectIdentifier SecP256k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".10"));

		public static readonly DerObjectIdentifier SecT163r2 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".15"));

		public static readonly DerObjectIdentifier SecT283k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".16"));

		public static readonly DerObjectIdentifier SecT283r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".17"));

		public static readonly DerObjectIdentifier SecT131r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".22"));

		public static readonly DerObjectIdentifier SecT131r2 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".23"));

		public static readonly DerObjectIdentifier SecT193r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".24"));

		public static readonly DerObjectIdentifier SecT193r2 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".25"));

		public static readonly DerObjectIdentifier SecT233k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".26"));

		public static readonly DerObjectIdentifier SecT233r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".27"));

		public static readonly DerObjectIdentifier SecP128r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".28"));

		public static readonly DerObjectIdentifier SecP128r2 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".29"));

		public static readonly DerObjectIdentifier SecP160r2 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".30"));

		public static readonly DerObjectIdentifier SecP192k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".31"));

		public static readonly DerObjectIdentifier SecP224k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".32"));

		public static readonly DerObjectIdentifier SecP224r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".33"));

		public static readonly DerObjectIdentifier SecP384r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".34"));

		public static readonly DerObjectIdentifier SecP521r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".35"));

		public static readonly DerObjectIdentifier SecT409k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".36"));

		public static readonly DerObjectIdentifier SecT409r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".37"));

		public static readonly DerObjectIdentifier SecT571k1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".38"));

		public static readonly DerObjectIdentifier SecT571r1 = new DerObjectIdentifier(string.Concat((object)EllipticCurve, (object)".39"));

		public static readonly DerObjectIdentifier SecP192r1 = X9ObjectIdentifiers.Prime192v1;

		public static readonly DerObjectIdentifier SecP256r1 = X9ObjectIdentifiers.Prime256v1;
	}
}
