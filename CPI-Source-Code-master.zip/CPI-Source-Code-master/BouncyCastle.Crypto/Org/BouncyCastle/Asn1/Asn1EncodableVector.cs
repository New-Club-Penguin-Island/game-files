using System;
using System.Collections;
using System.Reflection;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1
{
	[DefaultMember("Item")]
	public class Asn1EncodableVector : global::System.Collections.IEnumerable
	{
		private global::System.Collections.IList v = Platform.CreateArrayList();

		public Asn1Encodable this[int index] => (Asn1Encodable)v.get_Item(index);

		[Obsolete("Use 'Count' property instead")]
		public int Size => ((global::System.Collections.ICollection)v).get_Count();

		public int Count => ((global::System.Collections.ICollection)v).get_Count();

		public static Asn1EncodableVector FromEnumerable(global::System.Collections.IEnumerable e)
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			global::System.Collections.IEnumerator enumerator = e.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1Encodable asn1Encodable = (Asn1Encodable)enumerator.get_Current();
					asn1EncodableVector.Add(asn1Encodable);
				}
				return asn1EncodableVector;
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public Asn1EncodableVector(params Asn1Encodable[] v)
		{
			Add(v);
		}

		public void Add(params Asn1Encodable[] objs)
		{
			foreach (Asn1Encodable asn1Encodable in objs)
			{
				v.Add((object)asn1Encodable);
			}
		}

		public void AddOptional(params Asn1Encodable[] objs)
		{
			if (objs == null)
			{
				return;
			}
			foreach (Asn1Encodable asn1Encodable in objs)
			{
				if (asn1Encodable != null)
				{
					v.Add((object)asn1Encodable);
				}
			}
		}

		[Obsolete("Use 'object[index]' syntax instead")]
		public Asn1Encodable Get(int index)
		{
			return this[index];
		}

		public global::System.Collections.IEnumerator GetEnumerator()
		{
			return ((global::System.Collections.IEnumerable)v).GetEnumerator();
		}
	}
}
