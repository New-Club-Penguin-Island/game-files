using System;

namespace Org.BouncyCastle.Asn1
{
	[Serializable]
	public class Asn1ParsingException : InvalidOperationException
	{
		public Asn1ParsingException()
			: this()
		{
		}

		public Asn1ParsingException(string message)
			: this(message)
		{
		}

		public Asn1ParsingException(string message, global::System.Exception exception)
			: this(message, exception)
		{
		}
	}
}
