using System;
using System.IO;

namespace Org.BouncyCastle.Asn1
{
	public class BerTaggedObjectParser : Asn1TaggedObjectParser, IAsn1Convertible
	{
		private bool _constructed;

		private int _tagNumber;

		private Asn1StreamParser _parser;

		public bool IsConstructed => _constructed;

		public int TagNo => _tagNumber;

		[Obsolete]
		internal BerTaggedObjectParser(int baseTag, int tagNumber, Stream contentStream)
			: this((baseTag & 0x20) != 0, tagNumber, new Asn1StreamParser(contentStream))
		{
		}

		internal BerTaggedObjectParser(bool constructed, int tagNumber, Asn1StreamParser parser)
		{
			_constructed = constructed;
			_tagNumber = tagNumber;
			_parser = parser;
		}

		public IAsn1Convertible GetObjectParser(int tag, bool isExplicit)
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			if (isExplicit)
			{
				if (!_constructed)
				{
					throw new IOException("Explicit tags must be constructed (see X.690 8.14.2)");
				}
				return _parser.ReadObject();
			}
			return _parser.ReadImplicit(_constructed, tag);
		}

		public Asn1Object ToAsn1Object()
		{
			//IL_001b: Expected O, but got Unknown
			try
			{
				return _parser.ReadTaggedObject(_constructed, _tagNumber);
			}
			catch (IOException val)
			{
				IOException val2 = val;
				throw new Asn1ParsingException(((global::System.Exception)(object)val2).get_Message());
			}
		}
	}
}
