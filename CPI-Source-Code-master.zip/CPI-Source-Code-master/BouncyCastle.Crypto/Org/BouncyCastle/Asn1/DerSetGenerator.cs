using System.IO;

namespace Org.BouncyCastle.Asn1
{
	public class DerSetGenerator : DerGenerator
	{
		private readonly MemoryStream _bOut = new MemoryStream();

		public DerSetGenerator(Stream outStream)
			: base(outStream)
		{
		}//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown


		public DerSetGenerator(Stream outStream, int tagNo, bool isExplicit)
			: base(outStream, tagNo, isExplicit)
		{
		}//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown


		public override void AddObject(Asn1Encodable obj)
		{
			new DerOutputStream((Stream)(object)_bOut).WriteObject(obj);
		}

		public override Stream GetRawOutputStream()
		{
			return (Stream)(object)_bOut;
		}

		public override void Close()
		{
			WriteDerEncoded(49, _bOut.ToArray());
		}
	}
}
