namespace Org.BouncyCastle.Asn1.IsisMtt
{
	public abstract class IsisMttObjectIdentifiers
	{
		public static readonly DerObjectIdentifier IdIsisMtt = new DerObjectIdentifier("1.3.36.8");

		public static readonly DerObjectIdentifier IdIsisMttCP = new DerObjectIdentifier(string.Concat((object)IdIsisMtt, (object)".1"));

		public static readonly DerObjectIdentifier IdIsisMttCPAccredited = new DerObjectIdentifier(string.Concat((object)IdIsisMttCP, (object)".1"));

		public static readonly DerObjectIdentifier IdIsisMttAT = new DerObjectIdentifier(string.Concat((object)IdIsisMtt, (object)".3"));

		public static readonly DerObjectIdentifier IdIsisMttATDateOfCertGen = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".1"));

		public static readonly DerObjectIdentifier IdIsisMttATProcuration = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".2"));

		public static readonly DerObjectIdentifier IdIsisMttATAdmission = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".3"));

		public static readonly DerObjectIdentifier IdIsisMttATMonetaryLimit = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".4"));

		public static readonly DerObjectIdentifier IdIsisMttATDeclarationOfMajority = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".5"));

		public static readonly DerObjectIdentifier IdIsisMttATIccsn = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".6"));

		public static readonly DerObjectIdentifier IdIsisMttATPKReference = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".7"));

		public static readonly DerObjectIdentifier IdIsisMttATRestriction = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".8"));

		public static readonly DerObjectIdentifier IdIsisMttATRetrieveIfAllowed = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".9"));

		public static readonly DerObjectIdentifier IdIsisMttATRequestedCertificate = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".10"));

		public static readonly DerObjectIdentifier IdIsisMttATNamingAuthorities = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".11"));

		public static readonly DerObjectIdentifier IdIsisMttATCertInDirSince = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".12"));

		public static readonly DerObjectIdentifier IdIsisMttATCertHash = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".13"));

		public static readonly DerObjectIdentifier IdIsisMttATNameAtBirth = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".14"));

		public static readonly DerObjectIdentifier IdIsisMttATAdditionalInformation = new DerObjectIdentifier(string.Concat((object)IdIsisMttAT, (object)".15"));

		public static readonly DerObjectIdentifier IdIsisMttATLiabilityLimitationFlag = new DerObjectIdentifier("0.2.262.1.10.12.0");
	}
}
