using System;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.IsisMtt.Ocsp
{
	public class CertHash : Asn1Encodable
	{
		private readonly AlgorithmIdentifier hashAlgorithm;

		private readonly byte[] certificateHash;

		public AlgorithmIdentifier HashAlgorithm => hashAlgorithm;

		public byte[] CertificateHash => (byte[])((global::System.Array)certificateHash).Clone();

		public static CertHash GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is CertHash)
			{
				return (CertHash)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new CertHash((Asn1Sequence)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		private CertHash(Asn1Sequence seq)
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			if (seq.Count != 2)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count));
			}
			hashAlgorithm = AlgorithmIdentifier.GetInstance(seq[0]);
			certificateHash = Asn1OctetString.GetInstance(seq[1]).GetOctets();
		}

		public CertHash(AlgorithmIdentifier hashAlgorithm, byte[] certificateHash)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			if (hashAlgorithm == null)
			{
				throw new ArgumentNullException("hashAlgorithm");
			}
			if (certificateHash == null)
			{
				throw new ArgumentNullException("certificateHash");
			}
			this.hashAlgorithm = hashAlgorithm;
			this.certificateHash = (byte[])((global::System.Array)certificateHash).Clone();
		}

		public override Asn1Object ToAsn1Object()
		{
			return new DerSequence(hashAlgorithm, new DerOctetString(certificateHash));
		}
	}
}
