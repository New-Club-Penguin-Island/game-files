using System;
using System.Collections;
using Org.BouncyCastle.Asn1.X500;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.IsisMtt.X509
{
	public class ProfessionInfo : Asn1Encodable
	{
		public static readonly DerObjectIdentifier Rechtsanwltin = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".1"));

		public static readonly DerObjectIdentifier Rechtsanwalt = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".2"));

		public static readonly DerObjectIdentifier Rechtsbeistand = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".3"));

		public static readonly DerObjectIdentifier Steuerberaterin = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".4"));

		public static readonly DerObjectIdentifier Steuerberater = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".5"));

		public static readonly DerObjectIdentifier Steuerbevollmchtigte = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".6"));

		public static readonly DerObjectIdentifier Steuerbevollmchtigter = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".7"));

		public static readonly DerObjectIdentifier Notarin = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".8"));

		public static readonly DerObjectIdentifier Notar = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".9"));

		public static readonly DerObjectIdentifier Notarvertreterin = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".10"));

		public static readonly DerObjectIdentifier Notarvertreter = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".11"));

		public static readonly DerObjectIdentifier Notariatsverwalterin = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".12"));

		public static readonly DerObjectIdentifier Notariatsverwalter = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".13"));

		public static readonly DerObjectIdentifier Wirtschaftsprferin = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".14"));

		public static readonly DerObjectIdentifier Wirtschaftsprfer = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".15"));

		public static readonly DerObjectIdentifier VereidigteBuchprferin = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".16"));

		public static readonly DerObjectIdentifier VereidigterBuchprfer = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".17"));

		public static readonly DerObjectIdentifier Patentanwltin = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".18"));

		public static readonly DerObjectIdentifier Patentanwalt = new DerObjectIdentifier(string.Concat((object)NamingAuthority.IdIsisMttATNamingAuthoritiesRechtWirtschaftSteuern, (object)".19"));

		private readonly NamingAuthority namingAuthority;

		private readonly Asn1Sequence professionItems;

		private readonly Asn1Sequence professionOids;

		private readonly string registrationNumber;

		private readonly Asn1OctetString addProfessionInfo;

		public virtual Asn1OctetString AddProfessionInfo => addProfessionInfo;

		public virtual NamingAuthority NamingAuthority => namingAuthority;

		public virtual string RegistrationNumber => registrationNumber;

		public static ProfessionInfo GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is ProfessionInfo)
			{
				return (ProfessionInfo)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new ProfessionInfo((Asn1Sequence)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		private ProfessionInfo(Asn1Sequence seq)
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_0070: Unknown result type (might be due to invalid IL or missing references)
			//IL_010d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0168: Unknown result type (might be due to invalid IL or missing references)
			//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
			if (seq.Count > 5)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count));
			}
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			enumerator.MoveNext();
			Asn1Encodable asn1Encodable = (Asn1Encodable)enumerator.get_Current();
			if (asn1Encodable is Asn1TaggedObject)
			{
				Asn1TaggedObject asn1TaggedObject = (Asn1TaggedObject)asn1Encodable;
				if (asn1TaggedObject.TagNo != 0)
				{
					throw new ArgumentException(string.Concat((object)"Bad tag number: ", (object)asn1TaggedObject.TagNo));
				}
				namingAuthority = NamingAuthority.GetInstance(asn1TaggedObject, isExplicit: true);
				enumerator.MoveNext();
				asn1Encodable = (Asn1Encodable)enumerator.get_Current();
			}
			professionItems = Asn1Sequence.GetInstance(asn1Encodable);
			if (enumerator.MoveNext())
			{
				asn1Encodable = (Asn1Encodable)enumerator.get_Current();
				if (asn1Encodable is Asn1Sequence)
				{
					professionOids = Asn1Sequence.GetInstance(asn1Encodable);
				}
				else if (asn1Encodable is DerPrintableString)
				{
					registrationNumber = DerPrintableString.GetInstance(asn1Encodable).GetString();
				}
				else
				{
					if (!(asn1Encodable is Asn1OctetString))
					{
						throw new ArgumentException("Bad object encountered: " + Platform.GetTypeName(asn1Encodable));
					}
					addProfessionInfo = Asn1OctetString.GetInstance(asn1Encodable);
				}
			}
			if (enumerator.MoveNext())
			{
				asn1Encodable = (Asn1Encodable)enumerator.get_Current();
				if (asn1Encodable is DerPrintableString)
				{
					registrationNumber = DerPrintableString.GetInstance(asn1Encodable).GetString();
				}
				else
				{
					if (!(asn1Encodable is DerOctetString))
					{
						throw new ArgumentException("Bad object encountered: " + Platform.GetTypeName(asn1Encodable));
					}
					addProfessionInfo = (DerOctetString)asn1Encodable;
				}
			}
			if (enumerator.MoveNext())
			{
				asn1Encodable = (Asn1Encodable)enumerator.get_Current();
				if (!(asn1Encodable is DerOctetString))
				{
					throw new ArgumentException("Bad object encountered: " + Platform.GetTypeName(asn1Encodable));
				}
				addProfessionInfo = (DerOctetString)asn1Encodable;
			}
		}

		public ProfessionInfo(NamingAuthority namingAuthority, DirectoryString[] professionItems, DerObjectIdentifier[] professionOids, string registrationNumber, Asn1OctetString addProfessionInfo)
		{
			this.namingAuthority = namingAuthority;
			this.professionItems = new DerSequence(professionItems);
			if (professionOids != null)
			{
				this.professionOids = new DerSequence(professionOids);
			}
			this.registrationNumber = registrationNumber;
			this.addProfessionInfo = addProfessionInfo;
		}

		public override Asn1Object ToAsn1Object()
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			if (namingAuthority != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: true, 0, namingAuthority));
			}
			asn1EncodableVector.Add(professionItems);
			if (professionOids != null)
			{
				asn1EncodableVector.Add(professionOids);
			}
			if (registrationNumber != null)
			{
				asn1EncodableVector.Add(new DerPrintableString(registrationNumber, validate: true));
			}
			if (addProfessionInfo != null)
			{
				asn1EncodableVector.Add(addProfessionInfo);
			}
			return new DerSequence(asn1EncodableVector);
		}

		public virtual DirectoryString[] GetProfessionItems()
		{
			DirectoryString[] array = new DirectoryString[professionItems.Count];
			for (int i = 0; i < professionItems.Count; i++)
			{
				array[i] = DirectoryString.GetInstance(professionItems[i]);
			}
			return array;
		}

		public virtual DerObjectIdentifier[] GetProfessionOids()
		{
			if (professionOids == null)
			{
				return new DerObjectIdentifier[0];
			}
			DerObjectIdentifier[] array = new DerObjectIdentifier[professionOids.Count];
			for (int i = 0; i < professionOids.Count; i++)
			{
				array[i] = DerObjectIdentifier.GetInstance(professionOids[i]);
			}
			return array;
		}
	}
}
