using System;
using System.Collections;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Math;

namespace Org.BouncyCastle.Asn1.Icao
{
	public class LdsSecurityObject : Asn1Encodable
	{
		public const int UBDataGroups = 16;

		private DerInteger version = new DerInteger(0);

		private AlgorithmIdentifier digestAlgorithmIdentifier;

		private DataGroupHash[] datagroupHash;

		private LdsVersionInfo versionInfo;

		public BigInteger Version => version.Value;

		public AlgorithmIdentifier DigestAlgorithmIdentifier => digestAlgorithmIdentifier;

		public LdsVersionInfo VersionInfo => versionInfo;

		public static LdsSecurityObject GetInstance(object obj)
		{
			if (obj is LdsSecurityObject)
			{
				return (LdsSecurityObject)obj;
			}
			if (obj != null)
			{
				return new LdsSecurityObject(Asn1Sequence.GetInstance(obj));
			}
			return null;
		}

		private LdsSecurityObject(Asn1Sequence seq)
		{
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			if (seq == null || seq.Count == 0)
			{
				throw new ArgumentException("null or empty sequence passed.");
			}
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			enumerator.MoveNext();
			version = DerInteger.GetInstance(enumerator.get_Current());
			enumerator.MoveNext();
			digestAlgorithmIdentifier = AlgorithmIdentifier.GetInstance(enumerator.get_Current());
			enumerator.MoveNext();
			Asn1Sequence instance = Asn1Sequence.GetInstance(enumerator.get_Current());
			if (version.Value.Equals(BigInteger.One))
			{
				enumerator.MoveNext();
				versionInfo = LdsVersionInfo.GetInstance(enumerator.get_Current());
			}
			CheckDatagroupHashSeqSize(instance.Count);
			datagroupHash = new DataGroupHash[instance.Count];
			for (int i = 0; i < instance.Count; i++)
			{
				datagroupHash[i] = DataGroupHash.GetInstance(instance[i]);
			}
		}

		public LdsSecurityObject(AlgorithmIdentifier digestAlgorithmIdentifier, DataGroupHash[] datagroupHash)
		{
			version = new DerInteger(0);
			this.digestAlgorithmIdentifier = digestAlgorithmIdentifier;
			this.datagroupHash = datagroupHash;
			CheckDatagroupHashSeqSize(datagroupHash.Length);
		}

		public LdsSecurityObject(AlgorithmIdentifier digestAlgorithmIdentifier, DataGroupHash[] datagroupHash, LdsVersionInfo versionInfo)
		{
			version = new DerInteger(1);
			this.digestAlgorithmIdentifier = digestAlgorithmIdentifier;
			this.datagroupHash = datagroupHash;
			this.versionInfo = versionInfo;
			CheckDatagroupHashSeqSize(datagroupHash.Length);
		}

		private void CheckDatagroupHashSeqSize(int size)
		{
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			if (size < 2 || size > 16)
			{
				throw new ArgumentException(string.Concat((object)"wrong size in DataGroupHashValues : not in (2..", (object)16, (object)")"));
			}
		}

		public DataGroupHash[] GetDatagroupHash()
		{
			return datagroupHash;
		}

		public override Asn1Object ToAsn1Object()
		{
			DerSequence derSequence = new DerSequence(datagroupHash);
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector(version, digestAlgorithmIdentifier, derSequence);
			if (versionInfo != null)
			{
				asn1EncodableVector.Add(versionInfo);
			}
			return new DerSequence(asn1EncodableVector);
		}
	}
}
