using System;
using System.Collections;
using Org.BouncyCastle.Asn1.X509;

namespace Org.BouncyCastle.Asn1.Crmf
{
	public class OptionalValidity : Asn1Encodable
	{
		private readonly Time notBefore;

		private readonly Time notAfter;

		public virtual Time NotBefore => notBefore;

		public virtual Time NotAfter => notAfter;

		private OptionalValidity(Asn1Sequence seq)
		{
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1TaggedObject asn1TaggedObject = (Asn1TaggedObject)enumerator.get_Current();
					if (asn1TaggedObject.TagNo == 0)
					{
						notBefore = Time.GetInstance(asn1TaggedObject, explicitly: true);
					}
					else
					{
						notAfter = Time.GetInstance(asn1TaggedObject, explicitly: true);
					}
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public static OptionalValidity GetInstance(object obj)
		{
			if (obj == null || obj is OptionalValidity)
			{
				return (OptionalValidity)obj;
			}
			return new OptionalValidity(Asn1Sequence.GetInstance(obj));
		}

		public override Asn1Object ToAsn1Object()
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			if (notBefore != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: true, 0, notBefore));
			}
			if (notAfter != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: true, 1, notAfter));
			}
			return new DerSequence(asn1EncodableVector);
		}
	}
}
