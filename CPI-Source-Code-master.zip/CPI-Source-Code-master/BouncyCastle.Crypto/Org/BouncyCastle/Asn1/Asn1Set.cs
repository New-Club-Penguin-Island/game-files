using System;
using System.Collections;
using System.IO;
using System.Reflection;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.Utilities.Collections;

namespace Org.BouncyCastle.Asn1
{
	[DefaultMember("Item")]
	public abstract class Asn1Set : Asn1Object, global::System.Collections.IEnumerable
	{
		private class Asn1SetParserImpl : Asn1SetParser, IAsn1Convertible
		{
			private readonly Asn1Set outer;

			private readonly int max;

			private int index;

			public Asn1SetParserImpl(Asn1Set outer)
			{
				this.outer = outer;
				max = outer.Count;
			}

			public IAsn1Convertible ReadObject()
			{
				if (index == max)
				{
					return null;
				}
				Asn1Encodable asn1Encodable = outer[index++];
				if (asn1Encodable is Asn1Sequence)
				{
					return ((Asn1Sequence)asn1Encodable).Parser;
				}
				if (asn1Encodable is Asn1Set)
				{
					return ((Asn1Set)asn1Encodable).Parser;
				}
				return asn1Encodable;
			}

			public virtual Asn1Object ToAsn1Object()
			{
				return outer;
			}
		}

		private class DerComparer : IComparer
		{
			public int Compare(object x, object y)
			{
				byte[] array = (byte[])x;
				byte[] array2 = (byte[])y;
				int num = Math.Min(array.Length, array2.Length);
				for (int i = 0; i != num; i++)
				{
					byte b = array[i];
					byte b2 = array2[i];
					if (b != b2)
					{
						if (b >= b2)
						{
							return 1;
						}
						return -1;
					}
				}
				if (array.Length > array2.Length)
				{
					if (!AllZeroesFrom(array, num))
					{
						return 1;
					}
					return 0;
				}
				if (array.Length < array2.Length)
				{
					if (!AllZeroesFrom(array2, num))
					{
						return -1;
					}
					return 0;
				}
				return 0;
			}

			private bool AllZeroesFrom(byte[] bs, int pos)
			{
				while (pos < bs.Length)
				{
					if (bs[pos++] != 0)
					{
						return false;
					}
				}
				return true;
			}
		}

		private readonly global::System.Collections.IList _set;

		public virtual Asn1Encodable this[int index] => (Asn1Encodable)_set.get_Item(index);

		[Obsolete("Use 'Count' property instead")]
		public int Size => Count;

		public virtual int Count => ((global::System.Collections.ICollection)_set).get_Count();

		public Asn1SetParser Parser => new Asn1SetParserImpl(this);

		public static Asn1Set GetInstance(object obj)
		{
			//IL_0047: Expected O, but got Unknown
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is Asn1Set)
			{
				return (Asn1Set)obj;
			}
			if (obj is Asn1SetParser)
			{
				return GetInstance(((Asn1SetParser)obj).ToAsn1Object());
			}
			if (obj is byte[])
			{
				try
				{
					return GetInstance(Asn1Object.FromByteArray((byte[])obj));
				}
				catch (IOException val)
				{
					IOException val2 = val;
					throw new ArgumentException("failed to construct set from byte[]: " + ((global::System.Exception)(object)val2).get_Message());
				}
			}
			if (obj is Asn1Encodable)
			{
				Asn1Object asn1Object = ((Asn1Encodable)obj).ToAsn1Object();
				if (asn1Object is Asn1Set)
				{
					return (Asn1Set)asn1Object;
				}
			}
			throw new ArgumentException("Unknown object in GetInstance: " + Platform.GetTypeName(obj), "obj");
		}

		public static Asn1Set GetInstance(Asn1TaggedObject obj, bool explicitly)
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
			Asn1Object @object = obj.GetObject();
			if (explicitly)
			{
				if (!obj.IsExplicit())
				{
					throw new ArgumentException("object implicit - explicit expected.");
				}
				return (Asn1Set)@object;
			}
			if (obj.IsExplicit())
			{
				return new DerSet(@object);
			}
			if (@object is Asn1Set)
			{
				return (Asn1Set)@object;
			}
			if (@object is Asn1Sequence)
			{
				Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
				Asn1Sequence asn1Sequence = (Asn1Sequence)@object;
				{
					global::System.Collections.IEnumerator enumerator = asn1Sequence.GetEnumerator();
					try
					{
						while (enumerator.MoveNext())
						{
							Asn1Encodable asn1Encodable = (Asn1Encodable)enumerator.get_Current();
							asn1EncodableVector.Add(asn1Encodable);
						}
					}
					finally
					{
						global::System.IDisposable disposable = enumerator as global::System.IDisposable;
						if (disposable != null)
						{
							disposable.Dispose();
						}
					}
				}
				return new DerSet(asn1EncodableVector, needsSorting: false);
			}
			throw new ArgumentException("Unknown object in GetInstance: " + Platform.GetTypeName(obj), "obj");
		}

		protected internal Asn1Set(int capacity)
		{
			_set = Platform.CreateArrayList(capacity);
		}

		public virtual global::System.Collections.IEnumerator GetEnumerator()
		{
			return ((global::System.Collections.IEnumerable)_set).GetEnumerator();
		}

		[Obsolete("Use GetEnumerator() instead")]
		public global::System.Collections.IEnumerator GetObjects()
		{
			return GetEnumerator();
		}

		[Obsolete("Use 'object[index]' syntax instead")]
		public Asn1Encodable GetObjectAt(int index)
		{
			return this[index];
		}

		public virtual Asn1Encodable[] ToArray()
		{
			Asn1Encodable[] array = new Asn1Encodable[Count];
			for (int i = 0; i < Count; i++)
			{
				array[i] = this[i];
			}
			return array;
		}

		protected override int Asn1GetHashCode()
		{
			int num = Count;
			global::System.Collections.IEnumerator enumerator = GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object current = enumerator.get_Current();
					num *= 17;
					num = ((current != null) ? (num ^ current.GetHashCode()) : (num ^ DerNull.Instance.GetHashCode()));
				}
				return num;
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		protected override bool Asn1Equals(Asn1Object asn1Object)
		{
			Asn1Set asn1Set = asn1Object as Asn1Set;
			if (asn1Set == null)
			{
				return false;
			}
			if (Count != asn1Set.Count)
			{
				return false;
			}
			global::System.Collections.IEnumerator enumerator = GetEnumerator();
			global::System.Collections.IEnumerator enumerator2 = asn1Set.GetEnumerator();
			while (enumerator.MoveNext() && enumerator2.MoveNext())
			{
				Asn1Object asn1Object2 = GetCurrent(enumerator).ToAsn1Object();
				Asn1Object obj = GetCurrent(enumerator2).ToAsn1Object();
				if (!asn1Object2.Equals(obj))
				{
					return false;
				}
			}
			return true;
		}

		private Asn1Encodable GetCurrent(global::System.Collections.IEnumerator e)
		{
			Asn1Encodable asn1Encodable = (Asn1Encodable)e.get_Current();
			if (asn1Encodable == null)
			{
				return DerNull.Instance;
			}
			return asn1Encodable;
		}

		protected internal void Sort()
		{
			if (((global::System.Collections.ICollection)_set).get_Count() >= 2)
			{
				Asn1Encodable[] array = new Asn1Encodable[((global::System.Collections.ICollection)_set).get_Count()];
				byte[][] array2 = new byte[((global::System.Collections.ICollection)_set).get_Count()][];
				for (int i = 0; i < ((global::System.Collections.ICollection)_set).get_Count(); i++)
				{
					array2[i] = (array[i] = (Asn1Encodable)_set.get_Item(i)).GetEncoded("DER");
				}
				global::System.Array.Sort((global::System.Array)array2, (global::System.Array)array, (IComparer)(object)new DerComparer());
				for (int j = 0; j < ((global::System.Collections.ICollection)_set).get_Count(); j++)
				{
					_set.set_Item(j, (object)array[j]);
				}
			}
		}

		protected internal void AddObject(Asn1Encodable obj)
		{
			_set.Add((object)obj);
		}

		public override string ToString()
		{
			return CollectionUtilities.ToString((global::System.Collections.IEnumerable)_set);
		}
	}
}
