using System;
using System.IO;
using Org.BouncyCastle.Utilities.IO;

namespace Org.BouncyCastle.Asn1
{
	internal class DefiniteLengthInputStream : LimitedInputStream
	{
		private static readonly byte[] EmptyBytes = new byte[0];

		private readonly int _originalLength;

		private int _remaining;

		internal int Remaining => _remaining;

		internal DefiniteLengthInputStream(Stream inStream, int length)
			: base(inStream, length)
		{
			//IL_0016: Unknown result type (might be due to invalid IL or missing references)
			if (length < 0)
			{
				throw new ArgumentException("negative lengths not allowed", "length");
			}
			_originalLength = length;
			_remaining = length;
			if (length == 0)
			{
				SetParentEofDetect(on: true);
			}
		}

		public override int ReadByte()
		{
			//IL_0053: Unknown result type (might be due to invalid IL or missing references)
			if (_remaining == 0)
			{
				return -1;
			}
			int num = _in.ReadByte();
			if (num < 0)
			{
				throw new EndOfStreamException(string.Concat(new object[4] { "DEF length ", _originalLength, " object truncated by ", _remaining }));
			}
			if (--_remaining == 0)
			{
				SetParentEofDetect(on: true);
			}
			return num;
		}

		public override int Read(byte[] buf, int off, int len)
		{
			//IL_0063: Unknown result type (might be due to invalid IL or missing references)
			if (_remaining == 0)
			{
				return 0;
			}
			int num = Math.Min(len, _remaining);
			int num2 = _in.Read(buf, off, num);
			if (num2 < 1)
			{
				throw new EndOfStreamException(string.Concat(new object[4] { "DEF length ", _originalLength, " object truncated by ", _remaining }));
			}
			if ((_remaining -= num2) == 0)
			{
				SetParentEofDetect(on: true);
			}
			return num2;
		}

		internal void ReadAllIntoByteArray(byte[] buf)
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_006d: Unknown result type (might be due to invalid IL or missing references)
			if (_remaining != buf.Length)
			{
				throw new ArgumentException("buffer length not right for data");
			}
			if ((_remaining -= Streams.ReadFully(_in, buf)) != 0)
			{
				throw new EndOfStreamException(string.Concat(new object[4] { "DEF length ", _originalLength, " object truncated by ", _remaining }));
			}
			SetParentEofDetect(on: true);
		}

		internal byte[] ToArray()
		{
			//IL_0071: Unknown result type (might be due to invalid IL or missing references)
			if (_remaining == 0)
			{
				return EmptyBytes;
			}
			byte[] array = new byte[_remaining];
			if ((_remaining -= Streams.ReadFully(_in, array)) != 0)
			{
				throw new EndOfStreamException(string.Concat(new object[4] { "DEF length ", _originalLength, " object truncated by ", _remaining }));
			}
			SetParentEofDetect(on: true);
			return array;
		}
	}
}
