using System;
using System.Collections;
using System.IO;
using System.Reflection;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.Utilities.Collections;

namespace Org.BouncyCastle.Asn1
{
	[DefaultMember("Item")]
	public abstract class Asn1Sequence : Asn1Object, global::System.Collections.IEnumerable
	{
		private class Asn1SequenceParserImpl : Asn1SequenceParser, IAsn1Convertible
		{
			private readonly Asn1Sequence outer;

			private readonly int max;

			private int index;

			public Asn1SequenceParserImpl(Asn1Sequence outer)
			{
				this.outer = outer;
				max = outer.Count;
			}

			public IAsn1Convertible ReadObject()
			{
				if (index == max)
				{
					return null;
				}
				Asn1Encodable asn1Encodable = outer[index++];
				if (asn1Encodable is Asn1Sequence)
				{
					return ((Asn1Sequence)asn1Encodable).Parser;
				}
				if (asn1Encodable is Asn1Set)
				{
					return ((Asn1Set)asn1Encodable).Parser;
				}
				return asn1Encodable;
			}

			public Asn1Object ToAsn1Object()
			{
				return outer;
			}
		}

		private readonly global::System.Collections.IList seq;

		public virtual Asn1SequenceParser Parser => new Asn1SequenceParserImpl(this);

		public virtual Asn1Encodable this[int index] => (Asn1Encodable)seq.get_Item(index);

		[Obsolete("Use 'Count' property instead")]
		public int Size => Count;

		public virtual int Count => ((global::System.Collections.ICollection)seq).get_Count();

		public static Asn1Sequence GetInstance(object obj)
		{
			//IL_0047: Expected O, but got Unknown
			//IL_0057: Unknown result type (might be due to invalid IL or missing references)
			//IL_0095: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is Asn1Sequence)
			{
				return (Asn1Sequence)obj;
			}
			if (obj is Asn1SequenceParser)
			{
				return GetInstance(((Asn1SequenceParser)obj).ToAsn1Object());
			}
			if (obj is byte[])
			{
				try
				{
					return GetInstance(Asn1Object.FromByteArray((byte[])obj));
				}
				catch (IOException val)
				{
					IOException val2 = val;
					throw new ArgumentException("failed to construct sequence from byte[]: " + ((global::System.Exception)(object)val2).get_Message());
				}
			}
			if (obj is Asn1Encodable)
			{
				Asn1Object asn1Object = ((Asn1Encodable)obj).ToAsn1Object();
				if (asn1Object is Asn1Sequence)
				{
					return (Asn1Sequence)asn1Object;
				}
			}
			throw new ArgumentException("Unknown object in GetInstance: " + Platform.GetTypeName(obj), "obj");
		}

		public static Asn1Sequence GetInstance(Asn1TaggedObject obj, bool explicitly)
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_0066: Unknown result type (might be due to invalid IL or missing references)
			Asn1Object @object = obj.GetObject();
			if (explicitly)
			{
				if (!obj.IsExplicit())
				{
					throw new ArgumentException("object implicit - explicit expected.");
				}
				return (Asn1Sequence)@object;
			}
			if (obj.IsExplicit())
			{
				if (obj is BerTaggedObject)
				{
					return new BerSequence(@object);
				}
				return new DerSequence(@object);
			}
			if (@object is Asn1Sequence)
			{
				return (Asn1Sequence)@object;
			}
			throw new ArgumentException("Unknown object in GetInstance: " + Platform.GetTypeName(obj), "obj");
		}

		protected internal Asn1Sequence(int capacity)
		{
			seq = Platform.CreateArrayList(capacity);
		}

		public virtual global::System.Collections.IEnumerator GetEnumerator()
		{
			return ((global::System.Collections.IEnumerable)seq).GetEnumerator();
		}

		[Obsolete("Use GetEnumerator() instead")]
		public global::System.Collections.IEnumerator GetObjects()
		{
			return GetEnumerator();
		}

		[Obsolete("Use 'object[index]' syntax instead")]
		public Asn1Encodable GetObjectAt(int index)
		{
			return this[index];
		}

		protected override int Asn1GetHashCode()
		{
			int num = Count;
			global::System.Collections.IEnumerator enumerator = GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object current = enumerator.get_Current();
					num *= 17;
					num = ((current != null) ? (num ^ current.GetHashCode()) : (num ^ DerNull.Instance.GetHashCode()));
				}
				return num;
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		protected override bool Asn1Equals(Asn1Object asn1Object)
		{
			Asn1Sequence asn1Sequence = asn1Object as Asn1Sequence;
			if (asn1Sequence == null)
			{
				return false;
			}
			if (Count != asn1Sequence.Count)
			{
				return false;
			}
			global::System.Collections.IEnumerator enumerator = GetEnumerator();
			global::System.Collections.IEnumerator enumerator2 = asn1Sequence.GetEnumerator();
			while (enumerator.MoveNext() && enumerator2.MoveNext())
			{
				Asn1Object asn1Object2 = GetCurrent(enumerator).ToAsn1Object();
				Asn1Object obj = GetCurrent(enumerator2).ToAsn1Object();
				if (!asn1Object2.Equals(obj))
				{
					return false;
				}
			}
			return true;
		}

		private Asn1Encodable GetCurrent(global::System.Collections.IEnumerator e)
		{
			Asn1Encodable asn1Encodable = (Asn1Encodable)e.get_Current();
			if (asn1Encodable == null)
			{
				return DerNull.Instance;
			}
			return asn1Encodable;
		}

		protected internal void AddObject(Asn1Encodable obj)
		{
			seq.Add((object)obj);
		}

		public override string ToString()
		{
			return CollectionUtilities.ToString((global::System.Collections.IEnumerable)seq);
		}
	}
}
