using System;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.Esf
{
	public class OtherRevVals : Asn1Encodable
	{
		private readonly DerObjectIdentifier otherRevValType;

		private readonly Asn1Object otherRevVals;

		public DerObjectIdentifier OtherRevValType => otherRevValType;

		public Asn1Object OtherRevValsObject => otherRevVals;

		public static OtherRevVals GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is OtherRevVals)
			{
				return (OtherRevVals)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new OtherRevVals((Asn1Sequence)obj);
			}
			throw new ArgumentException("Unknown object in 'OtherRevVals' factory: " + Platform.GetTypeName(obj), "obj");
		}

		private OtherRevVals(Asn1Sequence seq)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			if (seq == null)
			{
				throw new ArgumentNullException("seq");
			}
			if (seq.Count != 2)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count), "seq");
			}
			otherRevValType = (DerObjectIdentifier)seq[0].ToAsn1Object();
			otherRevVals = seq[1].ToAsn1Object();
		}

		public OtherRevVals(DerObjectIdentifier otherRevValType, Asn1Encodable otherRevVals)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_001c: Unknown result type (might be due to invalid IL or missing references)
			if (otherRevValType == null)
			{
				throw new ArgumentNullException("otherRevValType");
			}
			if (otherRevVals == null)
			{
				throw new ArgumentNullException("otherRevVals");
			}
			this.otherRevValType = otherRevValType;
			this.otherRevVals = otherRevVals.ToAsn1Object();
		}

		public override Asn1Object ToAsn1Object()
		{
			return new DerSequence(otherRevValType, otherRevVals);
		}
	}
}
