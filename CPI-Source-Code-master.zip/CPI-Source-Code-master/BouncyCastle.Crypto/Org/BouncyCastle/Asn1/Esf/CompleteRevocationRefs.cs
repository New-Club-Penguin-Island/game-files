using System;
using System.Collections;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.Utilities.Collections;

namespace Org.BouncyCastle.Asn1.Esf
{
	public class CompleteRevocationRefs : Asn1Encodable
	{
		private readonly Asn1Sequence crlOcspRefs;

		public static CompleteRevocationRefs GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is CompleteRevocationRefs)
			{
				return (CompleteRevocationRefs)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new CompleteRevocationRefs((Asn1Sequence)obj);
			}
			throw new ArgumentException("Unknown object in 'CompleteRevocationRefs' factory: " + Platform.GetTypeName(obj), "obj");
		}

		private CompleteRevocationRefs(Asn1Sequence seq)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			if (seq == null)
			{
				throw new ArgumentNullException("seq");
			}
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1Encodable asn1Encodable = (Asn1Encodable)enumerator.get_Current();
					CrlOcspRef.GetInstance(asn1Encodable.ToAsn1Object());
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			crlOcspRefs = seq;
		}

		public CompleteRevocationRefs(params CrlOcspRef[] crlOcspRefs)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			if (crlOcspRefs == null)
			{
				throw new ArgumentNullException("crlOcspRefs");
			}
			this.crlOcspRefs = new DerSequence(crlOcspRefs);
		}

		public CompleteRevocationRefs(global::System.Collections.IEnumerable crlOcspRefs)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			if (crlOcspRefs == null)
			{
				throw new ArgumentNullException("crlOcspRefs");
			}
			if (!CollectionUtilities.CheckElementsAreOfType(crlOcspRefs, typeof(CrlOcspRef)))
			{
				throw new ArgumentException("Must contain only 'CrlOcspRef' objects", "crlOcspRefs");
			}
			this.crlOcspRefs = new DerSequence(Asn1EncodableVector.FromEnumerable(crlOcspRefs));
		}

		public CrlOcspRef[] GetCrlOcspRefs()
		{
			CrlOcspRef[] array = new CrlOcspRef[crlOcspRefs.Count];
			for (int i = 0; i < crlOcspRefs.Count; i++)
			{
				array[i] = CrlOcspRef.GetInstance(crlOcspRefs[i].ToAsn1Object());
			}
			return array;
		}

		public override Asn1Object ToAsn1Object()
		{
			return crlOcspRefs;
		}
	}
}
