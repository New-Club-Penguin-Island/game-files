using System;
using System.Collections;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.Utilities.Collections;

namespace Org.BouncyCastle.Asn1.Esf
{
	public class CompleteCertificateRefs : Asn1Encodable
	{
		private readonly Asn1Sequence otherCertIDs;

		public static CompleteCertificateRefs GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is CompleteCertificateRefs)
			{
				return (CompleteCertificateRefs)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new CompleteCertificateRefs((Asn1Sequence)obj);
			}
			throw new ArgumentException("Unknown object in 'CompleteCertificateRefs' factory: " + Platform.GetTypeName(obj), "obj");
		}

		private CompleteCertificateRefs(Asn1Sequence seq)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			if (seq == null)
			{
				throw new ArgumentNullException("seq");
			}
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1Encodable asn1Encodable = (Asn1Encodable)enumerator.get_Current();
					OtherCertID.GetInstance(asn1Encodable.ToAsn1Object());
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			otherCertIDs = seq;
		}

		public CompleteCertificateRefs(params OtherCertID[] otherCertIDs)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			if (otherCertIDs == null)
			{
				throw new ArgumentNullException("otherCertIDs");
			}
			this.otherCertIDs = new DerSequence(otherCertIDs);
		}

		public CompleteCertificateRefs(global::System.Collections.IEnumerable otherCertIDs)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			if (otherCertIDs == null)
			{
				throw new ArgumentNullException("otherCertIDs");
			}
			if (!CollectionUtilities.CheckElementsAreOfType(otherCertIDs, typeof(OtherCertID)))
			{
				throw new ArgumentException("Must contain only 'OtherCertID' objects", "otherCertIDs");
			}
			this.otherCertIDs = new DerSequence(Asn1EncodableVector.FromEnumerable(otherCertIDs));
		}

		public OtherCertID[] GetOtherCertIDs()
		{
			OtherCertID[] array = new OtherCertID[otherCertIDs.Count];
			for (int i = 0; i < otherCertIDs.Count; i++)
			{
				array[i] = OtherCertID.GetInstance(otherCertIDs[i].ToAsn1Object());
			}
			return array;
		}

		public override Asn1Object ToAsn1Object()
		{
			return otherCertIDs;
		}
	}
}
