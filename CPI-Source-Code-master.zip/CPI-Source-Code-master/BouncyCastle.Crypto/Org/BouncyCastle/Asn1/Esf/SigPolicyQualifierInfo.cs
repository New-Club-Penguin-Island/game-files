using System;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.Esf
{
	public class SigPolicyQualifierInfo : Asn1Encodable
	{
		private readonly DerObjectIdentifier sigPolicyQualifierId;

		private readonly Asn1Object sigQualifier;

		public DerObjectIdentifier SigPolicyQualifierId => sigPolicyQualifierId;

		public Asn1Object SigQualifier => sigQualifier;

		public static SigPolicyQualifierInfo GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is SigPolicyQualifierInfo)
			{
				return (SigPolicyQualifierInfo)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new SigPolicyQualifierInfo((Asn1Sequence)obj);
			}
			throw new ArgumentException("Unknown object in 'SigPolicyQualifierInfo' factory: " + Platform.GetTypeName(obj), "obj");
		}

		private SigPolicyQualifierInfo(Asn1Sequence seq)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			if (seq == null)
			{
				throw new ArgumentNullException("seq");
			}
			if (seq.Count != 2)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count), "seq");
			}
			sigPolicyQualifierId = (DerObjectIdentifier)seq[0].ToAsn1Object();
			sigQualifier = seq[1].ToAsn1Object();
		}

		public SigPolicyQualifierInfo(DerObjectIdentifier sigPolicyQualifierId, Asn1Encodable sigQualifier)
		{
			this.sigPolicyQualifierId = sigPolicyQualifierId;
			this.sigQualifier = sigQualifier.ToAsn1Object();
		}

		public override Asn1Object ToAsn1Object()
		{
			return new DerSequence(sigPolicyQualifierId, sigQualifier);
		}
	}
}
