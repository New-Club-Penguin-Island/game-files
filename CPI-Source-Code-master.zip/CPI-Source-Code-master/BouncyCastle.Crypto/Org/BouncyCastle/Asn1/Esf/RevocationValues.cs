using System;
using System.Collections;
using Org.BouncyCastle.Asn1.Ocsp;
using Org.BouncyCastle.Asn1.X509;
using Org.BouncyCastle.Utilities.Collections;

namespace Org.BouncyCastle.Asn1.Esf
{
	public class RevocationValues : Asn1Encodable
	{
		private readonly Asn1Sequence crlVals;

		private readonly Asn1Sequence ocspVals;

		private readonly OtherRevVals otherRevVals;

		public OtherRevVals OtherRevVals => otherRevVals;

		public static RevocationValues GetInstance(object obj)
		{
			if (obj == null || obj is RevocationValues)
			{
				return (RevocationValues)obj;
			}
			return new RevocationValues(Asn1Sequence.GetInstance(obj));
		}

		private RevocationValues(Asn1Sequence seq)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0037: Unknown result type (might be due to invalid IL or missing references)
			//IL_0141: Unknown result type (might be due to invalid IL or missing references)
			if (seq == null)
			{
				throw new ArgumentNullException("seq");
			}
			if (seq.Count > 3)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count), "seq");
			}
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1TaggedObject asn1TaggedObject = (Asn1TaggedObject)enumerator.get_Current();
					Asn1Object @object = asn1TaggedObject.GetObject();
					switch (asn1TaggedObject.TagNo)
					{
					case 0:
					{
						Asn1Sequence asn1Sequence2 = (Asn1Sequence)@object;
						{
							global::System.Collections.IEnumerator enumerator2 = asn1Sequence2.GetEnumerator();
							try
							{
								while (enumerator2.MoveNext())
								{
									Asn1Encodable asn1Encodable2 = (Asn1Encodable)enumerator2.get_Current();
									CertificateList.GetInstance(asn1Encodable2.ToAsn1Object());
								}
							}
							finally
							{
								global::System.IDisposable disposable2 = enumerator2 as global::System.IDisposable;
								if (disposable2 != null)
								{
									disposable2.Dispose();
								}
							}
						}
						crlVals = asn1Sequence2;
						break;
					}
					case 1:
					{
						Asn1Sequence asn1Sequence = (Asn1Sequence)@object;
						{
							global::System.Collections.IEnumerator enumerator2 = asn1Sequence.GetEnumerator();
							try
							{
								while (enumerator2.MoveNext())
								{
									Asn1Encodable asn1Encodable = (Asn1Encodable)enumerator2.get_Current();
									BasicOcspResponse.GetInstance(asn1Encodable.ToAsn1Object());
								}
							}
							finally
							{
								global::System.IDisposable disposable3 = enumerator2 as global::System.IDisposable;
								if (disposable3 != null)
								{
									disposable3.Dispose();
								}
							}
						}
						ocspVals = asn1Sequence;
						break;
					}
					case 2:
						otherRevVals = OtherRevVals.GetInstance(@object);
						break;
					default:
						throw new ArgumentException("Illegal tag in RevocationValues", "seq");
					}
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public RevocationValues(CertificateList[] crlVals, BasicOcspResponse[] ocspVals, OtherRevVals otherRevVals)
		{
			if (crlVals != null)
			{
				this.crlVals = new DerSequence(crlVals);
			}
			if (ocspVals != null)
			{
				this.ocspVals = new DerSequence(ocspVals);
			}
			this.otherRevVals = otherRevVals;
		}

		public RevocationValues(global::System.Collections.IEnumerable crlVals, global::System.Collections.IEnumerable ocspVals, OtherRevVals otherRevVals)
		{
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			//IL_005b: Unknown result type (might be due to invalid IL or missing references)
			if (crlVals != null)
			{
				if (!CollectionUtilities.CheckElementsAreOfType(crlVals, typeof(CertificateList)))
				{
					throw new ArgumentException("Must contain only 'CertificateList' objects", "crlVals");
				}
				this.crlVals = new DerSequence(Asn1EncodableVector.FromEnumerable(crlVals));
			}
			if (ocspVals != null)
			{
				if (!CollectionUtilities.CheckElementsAreOfType(ocspVals, typeof(BasicOcspResponse)))
				{
					throw new ArgumentException("Must contain only 'BasicOcspResponse' objects", "ocspVals");
				}
				this.ocspVals = new DerSequence(Asn1EncodableVector.FromEnumerable(ocspVals));
			}
			this.otherRevVals = otherRevVals;
		}

		public CertificateList[] GetCrlVals()
		{
			CertificateList[] array = new CertificateList[crlVals.Count];
			for (int i = 0; i < crlVals.Count; i++)
			{
				array[i] = CertificateList.GetInstance(crlVals[i].ToAsn1Object());
			}
			return array;
		}

		public BasicOcspResponse[] GetOcspVals()
		{
			BasicOcspResponse[] array = new BasicOcspResponse[ocspVals.Count];
			for (int i = 0; i < ocspVals.Count; i++)
			{
				array[i] = BasicOcspResponse.GetInstance(ocspVals[i].ToAsn1Object());
			}
			return array;
		}

		public override Asn1Object ToAsn1Object()
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			if (crlVals != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: true, 0, crlVals));
			}
			if (ocspVals != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: true, 1, ocspVals));
			}
			if (otherRevVals != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: true, 2, otherRevVals.ToAsn1Object()));
			}
			return new DerSequence(asn1EncodableVector);
		}
	}
}
