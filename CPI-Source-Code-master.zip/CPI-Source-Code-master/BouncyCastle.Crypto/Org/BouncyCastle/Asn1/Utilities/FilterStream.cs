using System;
using System.IO;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.Utilities
{
	[Obsolete("Use Org.BouncyCastle.Utilities.IO.FilterStream")]
	public class FilterStream : Stream
	{
		protected readonly Stream s;

		public override bool CanRead => s.get_CanRead();

		public override bool CanSeek => s.get_CanSeek();

		public override bool CanWrite => s.get_CanWrite();

		public override long Length => s.get_Length();

		public override long Position
		{
			get
			{
				return s.get_Position();
			}
			set
			{
				s.set_Position(value);
			}
		}

		[Obsolete("Use Org.BouncyCastle.Utilities.IO.FilterStream")]
		public FilterStream(Stream s)
			: this()
		{
			this.s = s;
		}

		public override void Close()
		{
			Platform.Dispose(s);
			((Stream)this).Close();
		}

		public override void Flush()
		{
			s.Flush();
		}

		public override long Seek(long offset, SeekOrigin origin)
		{
			//IL_0007: Unknown result type (might be due to invalid IL or missing references)
			return s.Seek(offset, origin);
		}

		public override void SetLength(long value)
		{
			s.SetLength(value);
		}

		public override int Read(byte[] buffer, int offset, int count)
		{
			return s.Read(buffer, offset, count);
		}

		public override int ReadByte()
		{
			return s.ReadByte();
		}

		public override void Write(byte[] buffer, int offset, int count)
		{
			s.Write(buffer, offset, count);
		}

		public override void WriteByte(byte value)
		{
			s.WriteByte(value);
		}
	}
}
