using System.Collections;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Math;
using Org.BouncyCastle.Math.EC;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.Utilities.Collections;

namespace Org.BouncyCastle.Asn1.CryptoPro
{
	public sealed class ECGost3410NamedCurves
	{
		internal static readonly IDictionary objIds;

		internal static readonly IDictionary parameters;

		internal static readonly IDictionary names;

		public static global::System.Collections.IEnumerable Names => new EnumerableProxy((global::System.Collections.IEnumerable)names.get_Values());

		private ECGost3410NamedCurves()
		{
		}

		static ECGost3410NamedCurves()
		{
			objIds = Platform.CreateHashtable();
			parameters = Platform.CreateHashtable();
			names = Platform.CreateHashtable();
			BigInteger q = new BigInteger("115792089237316195423570985008687907853269984665640564039457584007913129639319");
			BigInteger bigInteger = new BigInteger("115792089237316195423570985008687907853073762908499243225378155805079068850323");
			FpCurve fpCurve = new FpCurve(q, new BigInteger("115792089237316195423570985008687907853269984665640564039457584007913129639316"), new BigInteger("166"), bigInteger, BigInteger.One);
			ECDomainParameters eCDomainParameters = new ECDomainParameters(fpCurve, fpCurve.CreatePoint(new BigInteger("1"), new BigInteger("64033881142927202683649881450433473985931760268884941288852745803908878638612")), bigInteger);
			parameters.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProA, (object)eCDomainParameters);
			q = new BigInteger("115792089237316195423570985008687907853269984665640564039457584007913129639319");
			bigInteger = new BigInteger("115792089237316195423570985008687907853073762908499243225378155805079068850323");
			fpCurve = new FpCurve(q, new BigInteger("115792089237316195423570985008687907853269984665640564039457584007913129639316"), new BigInteger("166"), bigInteger, BigInteger.One);
			eCDomainParameters = new ECDomainParameters(fpCurve, fpCurve.CreatePoint(new BigInteger("1"), new BigInteger("64033881142927202683649881450433473985931760268884941288852745803908878638612")), bigInteger);
			parameters.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProXchA, (object)eCDomainParameters);
			q = new BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564823193");
			bigInteger = new BigInteger("57896044618658097711785492504343953927102133160255826820068844496087732066703");
			fpCurve = new FpCurve(q, new BigInteger("57896044618658097711785492504343953926634992332820282019728792003956564823190"), new BigInteger("28091019353058090096996979000309560759124368558014865957655842872397301267595"), bigInteger, BigInteger.One);
			eCDomainParameters = new ECDomainParameters(fpCurve, fpCurve.CreatePoint(new BigInteger("1"), new BigInteger("28792665814854611296992347458380284135028636778229113005756334730996303888124")), bigInteger);
			parameters.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProB, (object)eCDomainParameters);
			q = new BigInteger("70390085352083305199547718019018437841079516630045180471284346843705633502619");
			bigInteger = new BigInteger("70390085352083305199547718019018437840920882647164081035322601458352298396601");
			fpCurve = new FpCurve(q, new BigInteger("70390085352083305199547718019018437841079516630045180471284346843705633502616"), new BigInteger("32858"), bigInteger, BigInteger.One);
			eCDomainParameters = new ECDomainParameters(fpCurve, fpCurve.CreatePoint(new BigInteger("0"), new BigInteger("29818893917731240733471273240314769927240550812383695689146495261604565990247")), bigInteger);
			parameters.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProXchB, (object)eCDomainParameters);
			q = new BigInteger("70390085352083305199547718019018437841079516630045180471284346843705633502619");
			bigInteger = new BigInteger("70390085352083305199547718019018437840920882647164081035322601458352298396601");
			fpCurve = new FpCurve(q, new BigInteger("70390085352083305199547718019018437841079516630045180471284346843705633502616"), new BigInteger("32858"), bigInteger, BigInteger.One);
			eCDomainParameters = new ECDomainParameters(fpCurve, fpCurve.CreatePoint(new BigInteger("0"), new BigInteger("29818893917731240733471273240314769927240550812383695689146495261604565990247")), bigInteger);
			parameters.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProC, (object)eCDomainParameters);
			objIds.set_Item((object)"GostR3410-2001-CryptoPro-A", (object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProA);
			objIds.set_Item((object)"GostR3410-2001-CryptoPro-B", (object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProB);
			objIds.set_Item((object)"GostR3410-2001-CryptoPro-C", (object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProC);
			objIds.set_Item((object)"GostR3410-2001-CryptoPro-XchA", (object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProXchA);
			objIds.set_Item((object)"GostR3410-2001-CryptoPro-XchB", (object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProXchB);
			names.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProA, (object)"GostR3410-2001-CryptoPro-A");
			names.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProB, (object)"GostR3410-2001-CryptoPro-B");
			names.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProC, (object)"GostR3410-2001-CryptoPro-C");
			names.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProXchA, (object)"GostR3410-2001-CryptoPro-XchA");
			names.set_Item((object)CryptoProObjectIdentifiers.GostR3410x2001CryptoProXchB, (object)"GostR3410-2001-CryptoPro-XchB");
		}

		public static ECDomainParameters GetByOid(DerObjectIdentifier oid)
		{
			return (ECDomainParameters)parameters.get_Item((object)oid);
		}

		public static ECDomainParameters GetByName(string name)
		{
			DerObjectIdentifier derObjectIdentifier = (DerObjectIdentifier)objIds.get_Item((object)name);
			if (derObjectIdentifier != null)
			{
				return (ECDomainParameters)parameters.get_Item((object)derObjectIdentifier);
			}
			return null;
		}

		public static string GetName(DerObjectIdentifier oid)
		{
			return (string)names.get_Item((object)oid);
		}

		public static DerObjectIdentifier GetOid(string name)
		{
			return (DerObjectIdentifier)objIds.get_Item((object)name);
		}
	}
}
