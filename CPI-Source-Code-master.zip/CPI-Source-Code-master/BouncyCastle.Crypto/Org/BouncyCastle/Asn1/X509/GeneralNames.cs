using System;
using System.Text;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509
{
	public class GeneralNames : Asn1Encodable
	{
		private readonly GeneralName[] names;

		public static GeneralNames GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is GeneralNames)
			{
				return (GeneralNames)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new GeneralNames((Asn1Sequence)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		public static GeneralNames GetInstance(Asn1TaggedObject obj, bool explicitly)
		{
			return GetInstance(Asn1Sequence.GetInstance(obj, explicitly));
		}

		public GeneralNames(GeneralName name)
		{
			names = new GeneralName[1] { name };
		}

		public GeneralNames(GeneralName[] names)
		{
			this.names = (GeneralName[])((global::System.Array)names).Clone();
		}

		private GeneralNames(Asn1Sequence seq)
		{
			names = new GeneralName[seq.Count];
			for (int i = 0; i != seq.Count; i++)
			{
				names[i] = GeneralName.GetInstance(seq[i]);
			}
		}

		public GeneralName[] GetNames()
		{
			return (GeneralName[])((global::System.Array)names).Clone();
		}

		public override Asn1Object ToAsn1Object()
		{
			return new DerSequence(names);
		}

		public override string ToString()
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Expected O, but got Unknown
			StringBuilder val = new StringBuilder();
			string newLine = Platform.NewLine;
			val.Append("GeneralNames:");
			val.Append(newLine);
			GeneralName[] array = names;
			foreach (GeneralName generalName in array)
			{
				val.Append("    ");
				val.Append((object)generalName);
				val.Append(newLine);
			}
			return val.ToString();
		}
	}
}
