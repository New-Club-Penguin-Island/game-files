using System;
using System.Globalization;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509
{
	public class Time : Asn1Encodable, IAsn1Choice
	{
		private readonly Asn1Object time;

		public static Time GetInstance(Asn1TaggedObject obj, bool explicitly)
		{
			return GetInstance(obj.GetObject());
		}

		public Time(Asn1Object time)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			if (time == null)
			{
				throw new ArgumentNullException("time");
			}
			if (!(time is DerUtcTime) && !(time is DerGeneralizedTime))
			{
				throw new ArgumentException("unknown object passed to Time");
			}
			this.time = time;
		}

		public Time(global::System.DateTime date)
		{
			string text = date.ToString("yyyyMMddHHmmss", (IFormatProvider)(object)CultureInfo.get_InvariantCulture()) + "Z";
			int num = int.Parse(text.Substring(0, 4));
			if (num < 1950 || num > 2049)
			{
				time = new DerGeneralizedTime(text);
			}
			else
			{
				time = new DerUtcTime(text.Substring(2));
			}
		}

		public static Time GetInstance(object obj)
		{
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is Time)
			{
				return (Time)obj;
			}
			if (obj is DerUtcTime)
			{
				return new Time((DerUtcTime)obj);
			}
			if (obj is DerGeneralizedTime)
			{
				return new Time((DerGeneralizedTime)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		public string GetTime()
		{
			if (time is DerUtcTime)
			{
				return ((DerUtcTime)time).AdjustedTimeString;
			}
			return ((DerGeneralizedTime)time).GetTime();
		}

		public global::System.DateTime ToDateTime()
		{
			//IL_0034: Expected O, but got Unknown
			//IL_0044: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				if (time is DerUtcTime)
				{
					return ((DerUtcTime)time).ToAdjustedDateTime();
				}
				return ((DerGeneralizedTime)time).ToDateTime();
			}
			catch (FormatException val)
			{
				FormatException val2 = val;
				throw new InvalidOperationException("invalid date string: " + ((global::System.Exception)(object)val2).get_Message());
			}
		}

		public override Asn1Object ToAsn1Object()
		{
			return time;
		}

		public override string ToString()
		{
			return GetTime();
		}
	}
}
