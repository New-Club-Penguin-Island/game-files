using System;
using System.Collections;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509
{
	public class CertificatePair : Asn1Encodable
	{
		private X509CertificateStructure forward;

		private X509CertificateStructure reverse;

		public X509CertificateStructure Forward => forward;

		public X509CertificateStructure Reverse => reverse;

		public static CertificatePair GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is CertificatePair)
			{
				return (CertificatePair)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new CertificatePair((Asn1Sequence)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		private CertificatePair(Asn1Sequence seq)
		{
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0093: Unknown result type (might be due to invalid IL or missing references)
			if (seq.Count != 1 && seq.Count != 2)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count), "seq");
			}
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object current = enumerator.get_Current();
					Asn1TaggedObject instance = Asn1TaggedObject.GetInstance(current);
					if (instance.TagNo == 0)
					{
						forward = X509CertificateStructure.GetInstance(instance, explicitly: true);
						continue;
					}
					if (instance.TagNo == 1)
					{
						reverse = X509CertificateStructure.GetInstance(instance, explicitly: true);
						continue;
					}
					throw new ArgumentException(string.Concat((object)"Bad tag number: ", (object)instance.TagNo));
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public CertificatePair(X509CertificateStructure forward, X509CertificateStructure reverse)
		{
			this.forward = forward;
			this.reverse = reverse;
		}

		public override Asn1Object ToAsn1Object()
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			if (forward != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(0, forward));
			}
			if (reverse != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(1, reverse));
			}
			return new DerSequence(asn1EncodableVector);
		}
	}
}
