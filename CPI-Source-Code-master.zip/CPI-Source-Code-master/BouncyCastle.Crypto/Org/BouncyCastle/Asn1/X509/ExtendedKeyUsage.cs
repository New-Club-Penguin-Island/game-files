using System;
using System.Collections;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509
{
	public class ExtendedKeyUsage : Asn1Encodable
	{
		internal readonly IDictionary usageTable = Platform.CreateHashtable();

		internal readonly Asn1Sequence seq;

		public int Count => ((global::System.Collections.ICollection)usageTable).get_Count();

		public static ExtendedKeyUsage GetInstance(Asn1TaggedObject obj, bool explicitly)
		{
			return GetInstance(Asn1Sequence.GetInstance(obj, explicitly));
		}

		public static ExtendedKeyUsage GetInstance(object obj)
		{
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			if (obj is ExtendedKeyUsage)
			{
				return (ExtendedKeyUsage)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new ExtendedKeyUsage((Asn1Sequence)obj);
			}
			if (obj is X509Extension)
			{
				return GetInstance(X509Extension.ConvertValueToObject((X509Extension)obj));
			}
			throw new ArgumentException("Invalid ExtendedKeyUsage: " + Platform.GetTypeName(obj));
		}

		private ExtendedKeyUsage(Asn1Sequence seq)
		{
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			this.seq = seq;
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object current = enumerator.get_Current();
					if (!(current is DerObjectIdentifier))
					{
						throw new ArgumentException("Only DerObjectIdentifier instances allowed in ExtendedKeyUsage.");
					}
					usageTable.set_Item(current, current);
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public ExtendedKeyUsage(params KeyPurposeID[] usages)
		{
			seq = new DerSequence(usages);
			foreach (KeyPurposeID keyPurposeID in usages)
			{
				usageTable.set_Item((object)keyPurposeID, (object)keyPurposeID);
			}
		}

		[Obsolete]
		public ExtendedKeyUsage(ArrayList usages)
			: this((global::System.Collections.IEnumerable)usages)
		{
		}

		public ExtendedKeyUsage(global::System.Collections.IEnumerable usages)
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			global::System.Collections.IEnumerator enumerator = usages.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object current = enumerator.get_Current();
					Asn1Encodable instance = DerObjectIdentifier.GetInstance(current);
					asn1EncodableVector.Add(instance);
					usageTable.set_Item((object)instance, (object)instance);
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			seq = new DerSequence(asn1EncodableVector);
		}

		public bool HasKeyPurposeId(KeyPurposeID keyPurposeId)
		{
			return usageTable.Contains((object)keyPurposeId);
		}

		[Obsolete("Use 'GetAllUsages'")]
		public ArrayList GetUsages()
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0011: Expected O, but got Unknown
			return new ArrayList(usageTable.get_Values());
		}

		public global::System.Collections.IList GetAllUsages()
		{
			return Platform.CreateArrayList(usageTable.get_Values());
		}

		public override Asn1Object ToAsn1Object()
		{
			return seq;
		}
	}
}
