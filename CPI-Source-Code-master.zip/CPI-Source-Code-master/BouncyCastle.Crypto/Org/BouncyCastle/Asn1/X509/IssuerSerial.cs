using System;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509
{
	public class IssuerSerial : Asn1Encodable
	{
		internal readonly GeneralNames issuer;

		internal readonly DerInteger serial;

		internal readonly DerBitString issuerUid;

		public GeneralNames Issuer => issuer;

		public DerInteger Serial => serial;

		public DerBitString IssuerUid => issuerUid;

		public static IssuerSerial GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is IssuerSerial)
			{
				return (IssuerSerial)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new IssuerSerial((Asn1Sequence)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		public static IssuerSerial GetInstance(Asn1TaggedObject obj, bool explicitly)
		{
			return GetInstance(Asn1Sequence.GetInstance(obj, explicitly));
		}

		private IssuerSerial(Asn1Sequence seq)
		{
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			if (seq.Count != 2 && seq.Count != 3)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count));
			}
			issuer = GeneralNames.GetInstance(seq[0]);
			serial = DerInteger.GetInstance(seq[1]);
			if (seq.Count == 3)
			{
				issuerUid = DerBitString.GetInstance(seq[2]);
			}
		}

		public IssuerSerial(GeneralNames issuer, DerInteger serial)
		{
			this.issuer = issuer;
			this.serial = serial;
		}

		public override Asn1Object ToAsn1Object()
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector(issuer, serial);
			if (issuerUid != null)
			{
				asn1EncodableVector.Add(issuerUid);
			}
			return new DerSequence(asn1EncodableVector);
		}
	}
}
