using System;
using System.Collections;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509
{
	public class X509ExtensionsGenerator
	{
		private IDictionary extensions = Platform.CreateHashtable();

		private global::System.Collections.IList extOrdering = Platform.CreateArrayList();

		public bool IsEmpty => ((global::System.Collections.ICollection)extOrdering).get_Count() < 1;

		public void Reset()
		{
			extensions = Platform.CreateHashtable();
			extOrdering = Platform.CreateArrayList();
		}

		public void AddExtension(DerObjectIdentifier oid, bool critical, Asn1Encodable extValue)
		{
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			byte[] derEncoded;
			try
			{
				derEncoded = extValue.GetDerEncoded();
			}
			catch (global::System.Exception ex)
			{
				throw new ArgumentException(string.Concat((object)"error encoding value: ", (object)ex));
			}
			AddExtension(oid, critical, derEncoded);
		}

		public void AddExtension(DerObjectIdentifier oid, bool critical, byte[] extValue)
		{
			//IL_001e: Unknown result type (might be due to invalid IL or missing references)
			if (extensions.Contains((object)oid))
			{
				throw new ArgumentException(string.Concat((object)"extension ", (object)oid, (object)" already added"));
			}
			extOrdering.Add((object)oid);
			extensions.Add((object)oid, (object)new X509Extension(critical, new DerOctetString(extValue)));
		}

		public X509Extensions Generate()
		{
			return new X509Extensions(extOrdering, extensions);
		}
	}
}
