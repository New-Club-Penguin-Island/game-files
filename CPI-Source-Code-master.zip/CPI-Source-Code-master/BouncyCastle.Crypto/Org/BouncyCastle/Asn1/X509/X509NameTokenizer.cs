using System.Text;

namespace Org.BouncyCastle.Asn1.X509
{
	public class X509NameTokenizer
	{
		private string value;

		private int index;

		private char separator;

		private StringBuilder buffer = new StringBuilder();

		public X509NameTokenizer(string oid)
			: this(oid, ',')
		{
		}

		public X509NameTokenizer(string oid, char separator)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			value = oid;
			index = -1;
			this.separator = separator;
		}

		public bool HasMoreTokens()
		{
			return index != value.get_Length();
		}

		public string NextToken()
		{
			if (index == value.get_Length())
			{
				return null;
			}
			int i = index + 1;
			bool flag = false;
			bool flag2 = false;
			buffer.Remove(0, buffer.get_Length());
			for (; i != value.get_Length(); i++)
			{
				char c = value.get_Chars(i);
				if (c == '"')
				{
					if (!flag2)
					{
						flag = !flag;
						continue;
					}
					buffer.Append(c);
					flag2 = false;
				}
				else if (flag2 || flag)
				{
					if (c == '#' && buffer.get_Chars(buffer.get_Length() - 1) == '=')
					{
						buffer.Append('\\');
					}
					else if (c == '+' && separator != '+')
					{
						buffer.Append('\\');
					}
					buffer.Append(c);
					flag2 = false;
				}
				else if (c == '\\')
				{
					flag2 = true;
				}
				else
				{
					if (c == separator)
					{
						break;
					}
					buffer.Append(c);
				}
			}
			index = i;
			return buffer.ToString().Trim();
		}
	}
}
