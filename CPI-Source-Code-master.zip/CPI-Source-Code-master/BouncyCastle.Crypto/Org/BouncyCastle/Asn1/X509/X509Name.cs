using System;
using System.Collections;
using System.IO;
using System.Text;
using Org.BouncyCastle.Asn1.Pkcs;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.Utilities.Encoders;

namespace Org.BouncyCastle.Asn1.X509
{
	public class X509Name : Asn1Encodable
	{
		public static readonly DerObjectIdentifier C;

		public static readonly DerObjectIdentifier O;

		public static readonly DerObjectIdentifier OU;

		public static readonly DerObjectIdentifier T;

		public static readonly DerObjectIdentifier CN;

		public static readonly DerObjectIdentifier Street;

		public static readonly DerObjectIdentifier SerialNumber;

		public static readonly DerObjectIdentifier L;

		public static readonly DerObjectIdentifier ST;

		public static readonly DerObjectIdentifier Surname;

		public static readonly DerObjectIdentifier GivenName;

		public static readonly DerObjectIdentifier Initials;

		public static readonly DerObjectIdentifier Generation;

		public static readonly DerObjectIdentifier UniqueIdentifier;

		public static readonly DerObjectIdentifier BusinessCategory;

		public static readonly DerObjectIdentifier PostalCode;

		public static readonly DerObjectIdentifier DnQualifier;

		public static readonly DerObjectIdentifier Pseudonym;

		public static readonly DerObjectIdentifier DateOfBirth;

		public static readonly DerObjectIdentifier PlaceOfBirth;

		public static readonly DerObjectIdentifier Gender;

		public static readonly DerObjectIdentifier CountryOfCitizenship;

		public static readonly DerObjectIdentifier CountryOfResidence;

		public static readonly DerObjectIdentifier NameAtBirth;

		public static readonly DerObjectIdentifier PostalAddress;

		public static readonly DerObjectIdentifier DmdName;

		public static readonly DerObjectIdentifier TelephoneNumber;

		public static readonly DerObjectIdentifier Name;

		public static readonly DerObjectIdentifier EmailAddress;

		public static readonly DerObjectIdentifier UnstructuredName;

		public static readonly DerObjectIdentifier UnstructuredAddress;

		public static readonly DerObjectIdentifier E;

		public static readonly DerObjectIdentifier DC;

		public static readonly DerObjectIdentifier UID;

		private static readonly bool[] defaultReverse;

		public static readonly Hashtable DefaultSymbols;

		public static readonly Hashtable RFC2253Symbols;

		public static readonly Hashtable RFC1779Symbols;

		public static readonly Hashtable DefaultLookup;

		private readonly global::System.Collections.IList ordering = Platform.CreateArrayList();

		private readonly X509NameEntryConverter converter;

		private global::System.Collections.IList values = Platform.CreateArrayList();

		private global::System.Collections.IList added = Platform.CreateArrayList();

		private Asn1Sequence seq;

		public static bool DefaultReverse
		{
			get
			{
				return defaultReverse[0];
			}
			set
			{
				defaultReverse[0] = value;
			}
		}

		static X509Name()
		{
			//IL_01ed: Unknown result type (might be due to invalid IL or missing references)
			//IL_01f7: Expected O, but got Unknown
			//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
			//IL_0201: Expected O, but got Unknown
			//IL_0201: Unknown result type (might be due to invalid IL or missing references)
			//IL_020b: Expected O, but got Unknown
			//IL_020b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0215: Expected O, but got Unknown
			C = new DerObjectIdentifier("2.5.4.6");
			O = new DerObjectIdentifier("2.5.4.10");
			OU = new DerObjectIdentifier("2.5.4.11");
			T = new DerObjectIdentifier("2.5.4.12");
			CN = new DerObjectIdentifier("2.5.4.3");
			Street = new DerObjectIdentifier("2.5.4.9");
			SerialNumber = new DerObjectIdentifier("2.5.4.5");
			L = new DerObjectIdentifier("2.5.4.7");
			ST = new DerObjectIdentifier("2.5.4.8");
			Surname = new DerObjectIdentifier("2.5.4.4");
			GivenName = new DerObjectIdentifier("2.5.4.42");
			Initials = new DerObjectIdentifier("2.5.4.43");
			Generation = new DerObjectIdentifier("2.5.4.44");
			UniqueIdentifier = new DerObjectIdentifier("2.5.4.45");
			BusinessCategory = new DerObjectIdentifier("2.5.4.15");
			PostalCode = new DerObjectIdentifier("2.5.4.17");
			DnQualifier = new DerObjectIdentifier("2.5.4.46");
			Pseudonym = new DerObjectIdentifier("2.5.4.65");
			DateOfBirth = new DerObjectIdentifier("1.3.6.1.5.5.7.9.1");
			PlaceOfBirth = new DerObjectIdentifier("1.3.6.1.5.5.7.9.2");
			Gender = new DerObjectIdentifier("1.3.6.1.5.5.7.9.3");
			CountryOfCitizenship = new DerObjectIdentifier("1.3.6.1.5.5.7.9.4");
			CountryOfResidence = new DerObjectIdentifier("1.3.6.1.5.5.7.9.5");
			NameAtBirth = new DerObjectIdentifier("1.3.36.8.3.14");
			PostalAddress = new DerObjectIdentifier("2.5.4.16");
			DmdName = new DerObjectIdentifier("2.5.4.54");
			TelephoneNumber = X509ObjectIdentifiers.id_at_telephoneNumber;
			Name = X509ObjectIdentifiers.id_at_name;
			EmailAddress = PkcsObjectIdentifiers.Pkcs9AtEmailAddress;
			UnstructuredName = PkcsObjectIdentifiers.Pkcs9AtUnstructuredName;
			UnstructuredAddress = PkcsObjectIdentifiers.Pkcs9AtUnstructuredAddress;
			E = EmailAddress;
			DC = new DerObjectIdentifier("0.9.2342.19200300.100.1.25");
			UID = new DerObjectIdentifier("0.9.2342.19200300.100.1.1");
			bool[] array = (defaultReverse = new bool[1]);
			DefaultSymbols = new Hashtable();
			RFC2253Symbols = new Hashtable();
			RFC1779Symbols = new Hashtable();
			DefaultLookup = new Hashtable();
			DefaultSymbols.Add((object)C, (object)"C");
			DefaultSymbols.Add((object)O, (object)"O");
			DefaultSymbols.Add((object)T, (object)"T");
			DefaultSymbols.Add((object)OU, (object)"OU");
			DefaultSymbols.Add((object)CN, (object)"CN");
			DefaultSymbols.Add((object)L, (object)"L");
			DefaultSymbols.Add((object)ST, (object)"ST");
			DefaultSymbols.Add((object)SerialNumber, (object)"SERIALNUMBER");
			DefaultSymbols.Add((object)EmailAddress, (object)"E");
			DefaultSymbols.Add((object)DC, (object)"DC");
			DefaultSymbols.Add((object)UID, (object)"UID");
			DefaultSymbols.Add((object)Street, (object)"STREET");
			DefaultSymbols.Add((object)Surname, (object)"SURNAME");
			DefaultSymbols.Add((object)GivenName, (object)"GIVENNAME");
			DefaultSymbols.Add((object)Initials, (object)"INITIALS");
			DefaultSymbols.Add((object)Generation, (object)"GENERATION");
			DefaultSymbols.Add((object)UnstructuredAddress, (object)"unstructuredAddress");
			DefaultSymbols.Add((object)UnstructuredName, (object)"unstructuredName");
			DefaultSymbols.Add((object)UniqueIdentifier, (object)"UniqueIdentifier");
			DefaultSymbols.Add((object)DnQualifier, (object)"DN");
			DefaultSymbols.Add((object)Pseudonym, (object)"Pseudonym");
			DefaultSymbols.Add((object)PostalAddress, (object)"PostalAddress");
			DefaultSymbols.Add((object)NameAtBirth, (object)"NameAtBirth");
			DefaultSymbols.Add((object)CountryOfCitizenship, (object)"CountryOfCitizenship");
			DefaultSymbols.Add((object)CountryOfResidence, (object)"CountryOfResidence");
			DefaultSymbols.Add((object)Gender, (object)"Gender");
			DefaultSymbols.Add((object)PlaceOfBirth, (object)"PlaceOfBirth");
			DefaultSymbols.Add((object)DateOfBirth, (object)"DateOfBirth");
			DefaultSymbols.Add((object)PostalCode, (object)"PostalCode");
			DefaultSymbols.Add((object)BusinessCategory, (object)"BusinessCategory");
			DefaultSymbols.Add((object)TelephoneNumber, (object)"TelephoneNumber");
			RFC2253Symbols.Add((object)C, (object)"C");
			RFC2253Symbols.Add((object)O, (object)"O");
			RFC2253Symbols.Add((object)OU, (object)"OU");
			RFC2253Symbols.Add((object)CN, (object)"CN");
			RFC2253Symbols.Add((object)L, (object)"L");
			RFC2253Symbols.Add((object)ST, (object)"ST");
			RFC2253Symbols.Add((object)Street, (object)"STREET");
			RFC2253Symbols.Add((object)DC, (object)"DC");
			RFC2253Symbols.Add((object)UID, (object)"UID");
			RFC1779Symbols.Add((object)C, (object)"C");
			RFC1779Symbols.Add((object)O, (object)"O");
			RFC1779Symbols.Add((object)OU, (object)"OU");
			RFC1779Symbols.Add((object)CN, (object)"CN");
			RFC1779Symbols.Add((object)L, (object)"L");
			RFC1779Symbols.Add((object)ST, (object)"ST");
			RFC1779Symbols.Add((object)Street, (object)"STREET");
			DefaultLookup.Add((object)"c", (object)C);
			DefaultLookup.Add((object)"o", (object)O);
			DefaultLookup.Add((object)"t", (object)T);
			DefaultLookup.Add((object)"ou", (object)OU);
			DefaultLookup.Add((object)"cn", (object)CN);
			DefaultLookup.Add((object)"l", (object)L);
			DefaultLookup.Add((object)"st", (object)ST);
			DefaultLookup.Add((object)"serialnumber", (object)SerialNumber);
			DefaultLookup.Add((object)"street", (object)Street);
			DefaultLookup.Add((object)"emailaddress", (object)E);
			DefaultLookup.Add((object)"dc", (object)DC);
			DefaultLookup.Add((object)"e", (object)E);
			DefaultLookup.Add((object)"uid", (object)UID);
			DefaultLookup.Add((object)"surname", (object)Surname);
			DefaultLookup.Add((object)"givenname", (object)GivenName);
			DefaultLookup.Add((object)"initials", (object)Initials);
			DefaultLookup.Add((object)"generation", (object)Generation);
			DefaultLookup.Add((object)"unstructuredaddress", (object)UnstructuredAddress);
			DefaultLookup.Add((object)"unstructuredname", (object)UnstructuredName);
			DefaultLookup.Add((object)"uniqueidentifier", (object)UniqueIdentifier);
			DefaultLookup.Add((object)"dn", (object)DnQualifier);
			DefaultLookup.Add((object)"pseudonym", (object)Pseudonym);
			DefaultLookup.Add((object)"postaladdress", (object)PostalAddress);
			DefaultLookup.Add((object)"nameofbirth", (object)NameAtBirth);
			DefaultLookup.Add((object)"countryofcitizenship", (object)CountryOfCitizenship);
			DefaultLookup.Add((object)"countryofresidence", (object)CountryOfResidence);
			DefaultLookup.Add((object)"gender", (object)Gender);
			DefaultLookup.Add((object)"placeofbirth", (object)PlaceOfBirth);
			DefaultLookup.Add((object)"dateofbirth", (object)DateOfBirth);
			DefaultLookup.Add((object)"postalcode", (object)PostalCode);
			DefaultLookup.Add((object)"businesscategory", (object)BusinessCategory);
			DefaultLookup.Add((object)"telephonenumber", (object)TelephoneNumber);
		}

		public static X509Name GetInstance(Asn1TaggedObject obj, bool explicitly)
		{
			return GetInstance(Asn1Sequence.GetInstance(obj, explicitly));
		}

		public static X509Name GetInstance(object obj)
		{
			//IL_002b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is X509Name)
			{
				return (X509Name)obj;
			}
			if (obj != null)
			{
				return new X509Name(Asn1Sequence.GetInstance(obj));
			}
			throw new ArgumentException("null object in factory", "obj");
		}

		protected X509Name()
		{
		}

		protected X509Name(Asn1Sequence seq)
		{
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			this.seq = seq;
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1Encodable asn1Encodable = (Asn1Encodable)enumerator.get_Current();
					Asn1Set instance = Asn1Set.GetInstance(asn1Encodable.ToAsn1Object());
					for (int i = 0; i < instance.Count; i++)
					{
						Asn1Sequence instance2 = Asn1Sequence.GetInstance(instance[i].ToAsn1Object());
						if (instance2.Count != 2)
						{
							throw new ArgumentException("badly sized pair");
						}
						ordering.Add((object)DerObjectIdentifier.GetInstance(instance2[0].ToAsn1Object()));
						Asn1Object asn1Object = instance2[1].ToAsn1Object();
						if (asn1Object is IAsn1String && !(asn1Object is DerUniversalString))
						{
							string text = ((IAsn1String)asn1Object).GetString();
							if (Platform.StartsWith(text, "#"))
							{
								text = "\\" + text;
							}
							values.Add((object)text);
						}
						else
						{
							values.Add((object)("#" + Hex.ToHexString(asn1Object.GetEncoded())));
						}
						added.Add((object)(i != 0));
					}
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public X509Name(global::System.Collections.IList ordering, IDictionary attributes)
			: this(ordering, attributes, new X509DefaultEntryConverter())
		{
		}

		public X509Name(global::System.Collections.IList ordering, IDictionary attributes, X509NameEntryConverter converter)
		{
			//IL_005e: Unknown result type (might be due to invalid IL or missing references)
			this.converter = converter;
			global::System.Collections.IEnumerator enumerator = ((global::System.Collections.IEnumerable)ordering).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					DerObjectIdentifier derObjectIdentifier = (DerObjectIdentifier)enumerator.get_Current();
					object obj = attributes.get_Item((object)derObjectIdentifier);
					if (obj == null)
					{
						throw new ArgumentException(string.Concat((object)"No attribute for object id - ", (object)derObjectIdentifier, (object)" - passed to distinguished name"));
					}
					this.ordering.Add((object)derObjectIdentifier);
					added.Add((object)false);
					values.Add(obj);
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public X509Name(global::System.Collections.IList oids, global::System.Collections.IList values)
			: this(oids, values, new X509DefaultEntryConverter())
		{
		}

		public X509Name(global::System.Collections.IList oids, global::System.Collections.IList values, X509NameEntryConverter converter)
		{
			//IL_0041: Unknown result type (might be due to invalid IL or missing references)
			this.converter = converter;
			if (((global::System.Collections.ICollection)oids).get_Count() != ((global::System.Collections.ICollection)values).get_Count())
			{
				throw new ArgumentException("'oids' must be same length as 'values'.");
			}
			for (int i = 0; i < ((global::System.Collections.ICollection)oids).get_Count(); i++)
			{
				ordering.Add(oids.get_Item(i));
				this.values.Add(values.get_Item(i));
				added.Add((object)false);
			}
		}

		public X509Name(string dirName)
			: this(DefaultReverse, (IDictionary)(object)DefaultLookup, dirName)
		{
		}

		public X509Name(string dirName, X509NameEntryConverter converter)
			: this(DefaultReverse, (IDictionary)(object)DefaultLookup, dirName, converter)
		{
		}

		public X509Name(bool reverse, string dirName)
			: this(reverse, (IDictionary)(object)DefaultLookup, dirName)
		{
		}

		public X509Name(bool reverse, string dirName, X509NameEntryConverter converter)
			: this(reverse, (IDictionary)(object)DefaultLookup, dirName, converter)
		{
		}

		public X509Name(bool reverse, IDictionary lookUp, string dirName)
			: this(reverse, lookUp, dirName, new X509DefaultEntryConverter())
		{
		}

		private DerObjectIdentifier DecodeOid(string name, IDictionary lookUp)
		{
			//IL_0061: Unknown result type (might be due to invalid IL or missing references)
			if (Platform.StartsWith(Platform.ToUpperInvariant(name), "OID."))
			{
				return new DerObjectIdentifier(name.Substring(4));
			}
			if (name.get_Chars(0) >= '0' && name.get_Chars(0) <= '9')
			{
				return new DerObjectIdentifier(name);
			}
			DerObjectIdentifier derObjectIdentifier = (DerObjectIdentifier)lookUp.get_Item((object)Platform.ToLowerInvariant(name));
			if (derObjectIdentifier == null)
			{
				throw new ArgumentException("Unknown object id - " + name + " - passed to distinguished name");
			}
			return derObjectIdentifier;
		}

		public X509Name(bool reverse, IDictionary lookUp, string dirName, X509NameEntryConverter converter)
		{
			//IL_0054: Unknown result type (might be due to invalid IL or missing references)
			this.converter = converter;
			X509NameTokenizer x509NameTokenizer = new X509NameTokenizer(dirName);
			while (x509NameTokenizer.HasMoreTokens())
			{
				string text = x509NameTokenizer.NextToken();
				int num = text.IndexOf('=');
				if (num == -1)
				{
					throw new ArgumentException("badly formated directory string");
				}
				string name = text.Substring(0, num);
				string text2 = text.Substring(num + 1);
				DerObjectIdentifier derObjectIdentifier = DecodeOid(name, lookUp);
				if (text2.IndexOf('+') > 0)
				{
					X509NameTokenizer x509NameTokenizer2 = new X509NameTokenizer(text2, '+');
					string text3 = x509NameTokenizer2.NextToken();
					ordering.Add((object)derObjectIdentifier);
					values.Add((object)text3);
					added.Add((object)false);
					while (x509NameTokenizer2.HasMoreTokens())
					{
						string text4 = x509NameTokenizer2.NextToken();
						int num2 = text4.IndexOf('=');
						string name2 = text4.Substring(0, num2);
						string text5 = text4.Substring(num2 + 1);
						ordering.Add((object)DecodeOid(name2, lookUp));
						values.Add((object)text5);
						added.Add((object)true);
					}
				}
				else
				{
					ordering.Add((object)derObjectIdentifier);
					values.Add((object)text2);
					added.Add((object)false);
				}
			}
			if (!reverse)
			{
				return;
			}
			global::System.Collections.IList list = Platform.CreateArrayList();
			global::System.Collections.IList list2 = Platform.CreateArrayList();
			global::System.Collections.IList list3 = Platform.CreateArrayList();
			int num3 = 1;
			for (int i = 0; i < ((global::System.Collections.ICollection)ordering).get_Count(); i++)
			{
				if (!(bool)added.get_Item(i))
				{
					num3 = 0;
				}
				int num4 = num3++;
				list.Insert(num4, ordering.get_Item(i));
				list2.Insert(num4, values.get_Item(i));
				list3.Insert(num4, added.get_Item(i));
			}
			ordering = list;
			values = list2;
			added = list3;
		}

		public global::System.Collections.IList GetOidList()
		{
			return Platform.CreateArrayList((global::System.Collections.ICollection)ordering);
		}

		public global::System.Collections.IList GetValueList()
		{
			return GetValueList(null);
		}

		public global::System.Collections.IList GetValueList(DerObjectIdentifier oid)
		{
			global::System.Collections.IList list = Platform.CreateArrayList();
			for (int i = 0; i != ((global::System.Collections.ICollection)values).get_Count(); i++)
			{
				if (oid == null || oid.Equals(ordering.get_Item(i)))
				{
					string text = (string)values.get_Item(i);
					if (Platform.StartsWith(text, "\\#"))
					{
						text = text.Substring(1);
					}
					list.Add((object)text);
				}
			}
			return list;
		}

		public override Asn1Object ToAsn1Object()
		{
			if (seq == null)
			{
				Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
				Asn1EncodableVector asn1EncodableVector2 = new Asn1EncodableVector();
				DerObjectIdentifier derObjectIdentifier = null;
				for (int i = 0; i != ((global::System.Collections.ICollection)ordering).get_Count(); i++)
				{
					DerObjectIdentifier derObjectIdentifier2 = (DerObjectIdentifier)ordering.get_Item(i);
					string value = (string)values.get_Item(i);
					if (derObjectIdentifier != null && !(bool)added.get_Item(i))
					{
						asn1EncodableVector.Add(new DerSet(asn1EncodableVector2));
						asn1EncodableVector2 = new Asn1EncodableVector();
					}
					asn1EncodableVector2.Add(new DerSequence(derObjectIdentifier2, converter.GetConvertedValue(derObjectIdentifier2, value)));
					derObjectIdentifier = derObjectIdentifier2;
				}
				asn1EncodableVector.Add(new DerSet(asn1EncodableVector2));
				seq = new DerSequence(asn1EncodableVector);
			}
			return seq;
		}

		public bool Equivalent(X509Name other, bool inOrder)
		{
			if (!inOrder)
			{
				return Equivalent(other);
			}
			if (other == null)
			{
				return false;
			}
			if (other == this)
			{
				return true;
			}
			int count = ((global::System.Collections.ICollection)ordering).get_Count();
			if (count != ((global::System.Collections.ICollection)other.ordering).get_Count())
			{
				return false;
			}
			for (int i = 0; i < count; i++)
			{
				DerObjectIdentifier derObjectIdentifier = (DerObjectIdentifier)ordering.get_Item(i);
				DerObjectIdentifier obj = (DerObjectIdentifier)other.ordering.get_Item(i);
				if (!derObjectIdentifier.Equals(obj))
				{
					return false;
				}
				string s = (string)values.get_Item(i);
				string s2 = (string)other.values.get_Item(i);
				if (!equivalentStrings(s, s2))
				{
					return false;
				}
			}
			return true;
		}

		public bool Equivalent(X509Name other)
		{
			if (other == null)
			{
				return false;
			}
			if (other == this)
			{
				return true;
			}
			int count = ((global::System.Collections.ICollection)ordering).get_Count();
			if (count != ((global::System.Collections.ICollection)other.ordering).get_Count())
			{
				return false;
			}
			bool[] array = new bool[count];
			int num;
			int num2;
			int num3;
			if (ordering.get_Item(0).Equals(other.ordering.get_Item(0)))
			{
				num = 0;
				num2 = count;
				num3 = 1;
			}
			else
			{
				num = count - 1;
				num2 = -1;
				num3 = -1;
			}
			for (int i = num; i != num2; i += num3)
			{
				bool flag = false;
				DerObjectIdentifier derObjectIdentifier = (DerObjectIdentifier)ordering.get_Item(i);
				string s = (string)values.get_Item(i);
				for (int j = 0; j < count; j++)
				{
					if (array[j])
					{
						continue;
					}
					DerObjectIdentifier obj = (DerObjectIdentifier)other.ordering.get_Item(j);
					if (derObjectIdentifier.Equals(obj))
					{
						string s2 = (string)other.values.get_Item(j);
						if (equivalentStrings(s, s2))
						{
							array[j] = true;
							flag = true;
							break;
						}
					}
				}
				if (!flag)
				{
					return false;
				}
			}
			return true;
		}

		private static bool equivalentStrings(string s1, string s2)
		{
			string text = canonicalize(s1);
			string text2 = canonicalize(s2);
			if (!text.Equals(text2))
			{
				text = stripInternalSpaces(text);
				text2 = stripInternalSpaces(text2);
				if (!text.Equals(text2))
				{
					return false;
				}
			}
			return true;
		}

		private static string canonicalize(string s)
		{
			string text = Platform.ToLowerInvariant(s).Trim();
			if (Platform.StartsWith(text, "#"))
			{
				Asn1Object asn1Object = decodeObject(text);
				if (asn1Object is IAsn1String)
				{
					text = Platform.ToLowerInvariant(((IAsn1String)asn1Object).GetString()).Trim();
				}
			}
			return text;
		}

		private static Asn1Object decodeObject(string v)
		{
			//IL_0015: Expected O, but got Unknown
			//IL_0026: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				return Asn1Object.FromByteArray(Hex.Decode(v.Substring(1)));
			}
			catch (IOException val)
			{
				IOException val2 = val;
				throw new InvalidOperationException("unknown encoding in name: " + ((global::System.Exception)(object)val2).get_Message(), (global::System.Exception)(object)val2);
			}
		}

		private static string stripInternalSpaces(string str)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Expected O, but got Unknown
			StringBuilder val = new StringBuilder();
			if (str.get_Length() != 0)
			{
				char c = str.get_Chars(0);
				val.Append(c);
				for (int i = 1; i < str.get_Length(); i++)
				{
					char c2 = str.get_Chars(i);
					if (c != ' ' || c2 != ' ')
					{
						val.Append(c2);
					}
					c = c2;
				}
			}
			return val.ToString();
		}

		private void AppendValue(StringBuilder buf, IDictionary oidSymbols, DerObjectIdentifier oid, string val)
		{
			string text = (string)oidSymbols.get_Item((object)oid);
			if (text != null)
			{
				buf.Append(text);
			}
			else
			{
				buf.Append(oid.Id);
			}
			buf.Append('=');
			int i = buf.get_Length();
			buf.Append(val);
			int num = buf.get_Length();
			if (Platform.StartsWith(val, "\\#"))
			{
				i += 2;
			}
			for (; i != num; i++)
			{
				if (buf.get_Chars(i) == ',' || buf.get_Chars(i) == '"' || buf.get_Chars(i) == '\\' || buf.get_Chars(i) == '+' || buf.get_Chars(i) == '=' || buf.get_Chars(i) == '<' || buf.get_Chars(i) == '>' || buf.get_Chars(i) == ';')
				{
					buf.Insert(i++, "\\");
					num++;
				}
			}
		}

		public string ToString(bool reverse, IDictionary oidSymbols)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Expected O, but got Unknown
			//IL_0058: Unknown result type (might be due to invalid IL or missing references)
			//IL_005e: Expected O, but got Unknown
			//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b4: Expected O, but got Unknown
			ArrayList val = new ArrayList();
			StringBuilder val2 = null;
			for (int i = 0; i < ((global::System.Collections.ICollection)ordering).get_Count(); i++)
			{
				if ((bool)added.get_Item(i))
				{
					val2.Append('+');
					AppendValue(val2, oidSymbols, (DerObjectIdentifier)ordering.get_Item(i), (string)values.get_Item(i));
				}
				else
				{
					val2 = new StringBuilder();
					AppendValue(val2, oidSymbols, (DerObjectIdentifier)ordering.get_Item(i), (string)values.get_Item(i));
					val.Add((object)val2);
				}
			}
			if (reverse)
			{
				val.Reverse();
			}
			StringBuilder val3 = new StringBuilder();
			if (val.get_Count() > 0)
			{
				val3.Append(val.get_Item(0).ToString());
				for (int j = 1; j < val.get_Count(); j++)
				{
					val3.Append(',');
					val3.Append(val.get_Item(j).ToString());
				}
			}
			return val3.ToString();
		}

		public override string ToString()
		{
			return ToString(DefaultReverse, (IDictionary)(object)DefaultSymbols);
		}
	}
}
