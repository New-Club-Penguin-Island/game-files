using System;
using System.Collections;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509
{
	public class PrivateKeyUsagePeriod : Asn1Encodable
	{
		private DerGeneralizedTime _notBefore;

		private DerGeneralizedTime _notAfter;

		public DerGeneralizedTime NotBefore => _notBefore;

		public DerGeneralizedTime NotAfter => _notAfter;

		public static PrivateKeyUsagePeriod GetInstance(object obj)
		{
			//IL_0051: Unknown result type (might be due to invalid IL or missing references)
			if (obj is PrivateKeyUsagePeriod)
			{
				return (PrivateKeyUsagePeriod)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new PrivateKeyUsagePeriod((Asn1Sequence)obj);
			}
			if (obj is X509Extension)
			{
				return GetInstance(X509Extension.ConvertValueToObject((X509Extension)obj));
			}
			throw new ArgumentException("unknown object in GetInstance: " + Platform.GetTypeName(obj), "obj");
		}

		private PrivateKeyUsagePeriod(Asn1Sequence seq)
		{
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1TaggedObject asn1TaggedObject = (Asn1TaggedObject)enumerator.get_Current();
					if (asn1TaggedObject.TagNo == 0)
					{
						_notBefore = DerGeneralizedTime.GetInstance(asn1TaggedObject, isExplicit: false);
					}
					else if (asn1TaggedObject.TagNo == 1)
					{
						_notAfter = DerGeneralizedTime.GetInstance(asn1TaggedObject, isExplicit: false);
					}
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public override Asn1Object ToAsn1Object()
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			if (_notBefore != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: false, 0, _notBefore));
			}
			if (_notAfter != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: false, 1, _notAfter));
			}
			return new DerSequence(asn1EncodableVector);
		}
	}
}
