using System;
using System.Collections;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.Utilities.Collections;

namespace Org.BouncyCastle.Asn1.X509
{
	public class TbsCertificateList : Asn1Encodable
	{
		private class RevokedCertificatesEnumeration : global::System.Collections.IEnumerable
		{
			private class RevokedCertificatesEnumerator : global::System.Collections.IEnumerator
			{
				private readonly global::System.Collections.IEnumerator e;

				public object Current => new CrlEntry(Asn1Sequence.GetInstance(e.get_Current()));

				internal RevokedCertificatesEnumerator(global::System.Collections.IEnumerator e)
				{
					this.e = e;
				}

				public bool MoveNext()
				{
					return e.MoveNext();
				}

				public void Reset()
				{
					e.Reset();
				}
			}

			private readonly global::System.Collections.IEnumerable en;

			internal RevokedCertificatesEnumeration(global::System.Collections.IEnumerable en)
			{
				this.en = en;
			}

			public global::System.Collections.IEnumerator GetEnumerator()
			{
				return new RevokedCertificatesEnumerator(en.GetEnumerator());
			}
		}

		internal Asn1Sequence seq;

		internal DerInteger version;

		internal AlgorithmIdentifier signature;

		internal X509Name issuer;

		internal Time thisUpdate;

		internal Time nextUpdate;

		internal Asn1Sequence revokedCertificates;

		internal X509Extensions crlExtensions;

		public int Version => version.Value.IntValue + 1;

		public DerInteger VersionNumber => version;

		public AlgorithmIdentifier Signature => signature;

		public X509Name Issuer => issuer;

		public Time ThisUpdate => thisUpdate;

		public Time NextUpdate => nextUpdate;

		public X509Extensions Extensions => crlExtensions;

		public static TbsCertificateList GetInstance(Asn1TaggedObject obj, bool explicitly)
		{
			return GetInstance(Asn1Sequence.GetInstance(obj, explicitly));
		}

		public static TbsCertificateList GetInstance(object obj)
		{
			//IL_0038: Unknown result type (might be due to invalid IL or missing references)
			TbsCertificateList tbsCertificateList = obj as TbsCertificateList;
			if (obj == null || tbsCertificateList != null)
			{
				return tbsCertificateList;
			}
			if (obj is Asn1Sequence)
			{
				return new TbsCertificateList((Asn1Sequence)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		internal TbsCertificateList(Asn1Sequence seq)
		{
			//IL_002d: Unknown result type (might be due to invalid IL or missing references)
			if (seq.Count < 3 || seq.Count > 7)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count));
			}
			int num = 0;
			this.seq = seq;
			if (seq[num] is DerInteger)
			{
				version = DerInteger.GetInstance(seq[num++]);
			}
			else
			{
				version = new DerInteger(0);
			}
			signature = AlgorithmIdentifier.GetInstance(seq[num++]);
			issuer = X509Name.GetInstance(seq[num++]);
			thisUpdate = Time.GetInstance(seq[num++]);
			if (num < seq.Count && (seq[num] is DerUtcTime || seq[num] is DerGeneralizedTime || seq[num] is Time))
			{
				nextUpdate = Time.GetInstance(seq[num++]);
			}
			if (num < seq.Count && !(seq[num] is DerTaggedObject))
			{
				revokedCertificates = Asn1Sequence.GetInstance(seq[num++]);
			}
			if (num < seq.Count && seq[num] is DerTaggedObject)
			{
				crlExtensions = X509Extensions.GetInstance(seq[num]);
			}
		}

		public CrlEntry[] GetRevokedCertificates()
		{
			if (revokedCertificates == null)
			{
				return new CrlEntry[0];
			}
			CrlEntry[] array = new CrlEntry[revokedCertificates.Count];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = new CrlEntry(Asn1Sequence.GetInstance(revokedCertificates[i]));
			}
			return array;
		}

		public global::System.Collections.IEnumerable GetRevokedCertificateEnumeration()
		{
			if (revokedCertificates == null)
			{
				return EmptyEnumerable.Instance;
			}
			return new RevokedCertificatesEnumeration(revokedCertificates);
		}

		public override Asn1Object ToAsn1Object()
		{
			return seq;
		}
	}
}
