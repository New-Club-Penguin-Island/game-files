using System;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509.Qualified
{
	public class Iso4217CurrencyCode : Asn1Encodable, IAsn1Choice
	{
		internal const int AlphabeticMaxSize = 3;

		internal const int NumericMinSize = 1;

		internal const int NumericMaxSize = 999;

		internal Asn1Encodable obj;

		public bool IsAlphabetic => obj is DerPrintableString;

		public string Alphabetic => ((DerPrintableString)obj).GetString();

		public int Numeric => ((DerInteger)obj).Value.IntValue;

		public static Iso4217CurrencyCode GetInstance(object obj)
		{
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is Iso4217CurrencyCode)
			{
				return (Iso4217CurrencyCode)obj;
			}
			if (obj is DerInteger)
			{
				DerInteger instance = DerInteger.GetInstance(obj);
				int intValue = instance.Value.IntValue;
				return new Iso4217CurrencyCode(intValue);
			}
			if (obj is DerPrintableString)
			{
				DerPrintableString instance2 = DerPrintableString.GetInstance(obj);
				return new Iso4217CurrencyCode(instance2.GetString());
			}
			throw new ArgumentException("unknown object in GetInstance: " + Platform.GetTypeName(obj), "obj");
		}

		public Iso4217CurrencyCode(int numeric)
		{
			//IL_004d: Unknown result type (might be due to invalid IL or missing references)
			if (numeric > 999 || numeric < 1)
			{
				throw new ArgumentException(string.Concat(new object[5] { "wrong size in numeric code : not in (", 1, "..", 999, ")" }));
			}
			obj = new DerInteger(numeric);
		}

		public Iso4217CurrencyCode(string alphabetic)
		{
			//IL_001f: Unknown result type (might be due to invalid IL or missing references)
			if (alphabetic.get_Length() > 3)
			{
				throw new ArgumentException(string.Concat((object)"wrong size in alphabetic code : max size is ", (object)3));
			}
			obj = new DerPrintableString(alphabetic);
		}

		public override Asn1Object ToAsn1Object()
		{
			return obj.ToAsn1Object();
		}
	}
}
