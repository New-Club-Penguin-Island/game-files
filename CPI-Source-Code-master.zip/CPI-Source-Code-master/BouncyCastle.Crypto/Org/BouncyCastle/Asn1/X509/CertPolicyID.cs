namespace Org.BouncyCastle.Asn1.X509
{
	public class CertPolicyID : DerObjectIdentifier
	{
		public CertPolicyID(string id)
			: base(id)
		{
		}
	}
}
