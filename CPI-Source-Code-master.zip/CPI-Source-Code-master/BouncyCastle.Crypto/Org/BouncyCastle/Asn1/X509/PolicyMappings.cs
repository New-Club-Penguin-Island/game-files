using System;
using System.Collections;

namespace Org.BouncyCastle.Asn1.X509
{
	public class PolicyMappings : Asn1Encodable
	{
		private readonly Asn1Sequence seq;

		public PolicyMappings(Asn1Sequence seq)
		{
			this.seq = seq;
		}

		public PolicyMappings(Hashtable mappings)
			: this((IDictionary)(object)mappings)
		{
		}

		public PolicyMappings(IDictionary mappings)
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			global::System.Collections.IEnumerator enumerator = ((global::System.Collections.IEnumerable)mappings.get_Keys()).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					string text = (string)enumerator.get_Current();
					string identifier = (string)mappings.get_Item((object)text);
					asn1EncodableVector.Add(new DerSequence(new DerObjectIdentifier(text), new DerObjectIdentifier(identifier)));
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			seq = new DerSequence(asn1EncodableVector);
		}

		public override Asn1Object ToAsn1Object()
		{
			return seq;
		}
	}
}
