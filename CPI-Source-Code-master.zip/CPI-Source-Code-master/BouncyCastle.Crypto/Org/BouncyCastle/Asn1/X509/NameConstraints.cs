using System;
using System.Collections;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509
{
	public class NameConstraints : Asn1Encodable
	{
		private Asn1Sequence permitted;

		private Asn1Sequence excluded;

		public Asn1Sequence PermittedSubtrees => permitted;

		public Asn1Sequence ExcludedSubtrees => excluded;

		public static NameConstraints GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is NameConstraints)
			{
				return (NameConstraints)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new NameConstraints((Asn1Sequence)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		public NameConstraints(Asn1Sequence seq)
		{
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1TaggedObject asn1TaggedObject = (Asn1TaggedObject)enumerator.get_Current();
					switch (asn1TaggedObject.TagNo)
					{
					case 0:
						permitted = Asn1Sequence.GetInstance(asn1TaggedObject, explicitly: false);
						break;
					case 1:
						excluded = Asn1Sequence.GetInstance(asn1TaggedObject, explicitly: false);
						break;
					}
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public NameConstraints(ArrayList permitted, ArrayList excluded)
			: this((global::System.Collections.IList)permitted, (global::System.Collections.IList)excluded)
		{
		}

		public NameConstraints(global::System.Collections.IList permitted, global::System.Collections.IList excluded)
		{
			if (permitted != null)
			{
				this.permitted = CreateSequence(permitted);
			}
			if (excluded != null)
			{
				this.excluded = CreateSequence(excluded);
			}
		}

		private DerSequence CreateSequence(global::System.Collections.IList subtrees)
		{
			GeneralSubtree[] array = new GeneralSubtree[((global::System.Collections.ICollection)subtrees).get_Count()];
			for (int i = 0; i < ((global::System.Collections.ICollection)subtrees).get_Count(); i++)
			{
				array[i] = (GeneralSubtree)subtrees.get_Item(i);
			}
			return new DerSequence(array);
		}

		public override Asn1Object ToAsn1Object()
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			if (permitted != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: false, 0, permitted));
			}
			if (excluded != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: false, 1, excluded));
			}
			return new DerSequence(asn1EncodableVector);
		}
	}
}
