using System;
using System.Collections;
using Org.BouncyCastle.Asn1.X500;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509.SigI
{
	public class NameOrPseudonym : Asn1Encodable, IAsn1Choice
	{
		private readonly DirectoryString pseudonym;

		private readonly DirectoryString surname;

		private readonly Asn1Sequence givenName;

		public DirectoryString Pseudonym => pseudonym;

		public DirectoryString Surname => surname;

		public static NameOrPseudonym GetInstance(object obj)
		{
			//IL_004f: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is NameOrPseudonym)
			{
				return (NameOrPseudonym)obj;
			}
			if (obj is IAsn1String)
			{
				return new NameOrPseudonym(DirectoryString.GetInstance(obj));
			}
			if (obj is Asn1Sequence)
			{
				return new NameOrPseudonym((Asn1Sequence)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		public NameOrPseudonym(DirectoryString pseudonym)
		{
			this.pseudonym = pseudonym;
		}

		private NameOrPseudonym(Asn1Sequence seq)
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_004e: Unknown result type (might be due to invalid IL or missing references)
			if (seq.Count != 2)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count));
			}
			if (!(seq[0] is IAsn1String))
			{
				throw new ArgumentException("Bad object encountered: " + Platform.GetTypeName(seq[0]));
			}
			surname = DirectoryString.GetInstance(seq[0]);
			givenName = Asn1Sequence.GetInstance(seq[1]);
		}

		public NameOrPseudonym(string pseudonym)
			: this(new DirectoryString(pseudonym))
		{
		}

		public NameOrPseudonym(DirectoryString surname, Asn1Sequence givenName)
		{
			this.surname = surname;
			this.givenName = givenName;
		}

		public DirectoryString[] GetGivenName()
		{
			DirectoryString[] array = new DirectoryString[givenName.Count];
			int num = 0;
			global::System.Collections.IEnumerator enumerator = givenName.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object current = enumerator.get_Current();
					array[num++] = DirectoryString.GetInstance(current);
				}
				return array;
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public override Asn1Object ToAsn1Object()
		{
			if (pseudonym != null)
			{
				return pseudonym.ToAsn1Object();
			}
			return new DerSequence(surname, givenName);
		}
	}
}
