using System;
using System.Collections;
using Org.BouncyCastle.Utilities;
using Org.BouncyCastle.Utilities.Collections;

namespace Org.BouncyCastle.Asn1.X509
{
	public class SubjectDirectoryAttributes : Asn1Encodable
	{
		private readonly global::System.Collections.IList attributes;

		public global::System.Collections.IEnumerable Attributes => new EnumerableProxy((global::System.Collections.IEnumerable)attributes);

		public static SubjectDirectoryAttributes GetInstance(object obj)
		{
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is SubjectDirectoryAttributes)
			{
				return (SubjectDirectoryAttributes)obj;
			}
			if (obj is Asn1Sequence)
			{
				return new SubjectDirectoryAttributes((Asn1Sequence)obj);
			}
			throw new ArgumentException("unknown object in factory: " + Platform.GetTypeName(obj), "obj");
		}

		private SubjectDirectoryAttributes(Asn1Sequence seq)
		{
			attributes = Platform.CreateArrayList();
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object current = enumerator.get_Current();
					Asn1Sequence instance = Asn1Sequence.GetInstance(current);
					attributes.Add((object)AttributeX509.GetInstance(instance));
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		[Obsolete]
		public SubjectDirectoryAttributes(ArrayList attributes)
			: this((global::System.Collections.IList)attributes)
		{
		}

		public SubjectDirectoryAttributes(global::System.Collections.IList attributes)
		{
			this.attributes = Platform.CreateArrayList((global::System.Collections.ICollection)attributes);
		}

		public override Asn1Object ToAsn1Object()
		{
			AttributeX509[] array = new AttributeX509[((global::System.Collections.ICollection)attributes).get_Count()];
			for (int i = 0; i < ((global::System.Collections.ICollection)attributes).get_Count(); i++)
			{
				array[i] = (AttributeX509)attributes.get_Item(i);
			}
			return new DerSequence(array);
		}
	}
}
