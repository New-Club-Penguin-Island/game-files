using System;
using System.Collections;
using Org.BouncyCastle.Math;

namespace Org.BouncyCastle.Asn1.X509
{
	public class NoticeReference : Asn1Encodable
	{
		private readonly DisplayText organization;

		private readonly Asn1Sequence noticeNumbers;

		public virtual DisplayText Organization => organization;

		private static Asn1EncodableVector ConvertVector(global::System.Collections.IList numbers)
		{
			//IL_0049: Unknown result type (might be due to invalid IL or missing references)
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			global::System.Collections.IEnumerator enumerator = ((global::System.Collections.IEnumerable)numbers).GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					object current = enumerator.get_Current();
					DerInteger derInteger;
					if (current is BigInteger)
					{
						derInteger = new DerInteger((BigInteger)current);
					}
					else
					{
						if (!(current is int))
						{
							throw new ArgumentException();
						}
						derInteger = new DerInteger((int)current);
					}
					asn1EncodableVector.Add(derInteger);
				}
				return asn1EncodableVector;
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public NoticeReference(string organization, global::System.Collections.IList numbers)
			: this(organization, ConvertVector(numbers))
		{
		}

		public NoticeReference(string organization, Asn1EncodableVector noticeNumbers)
			: this(new DisplayText(organization), noticeNumbers)
		{
		}

		public NoticeReference(DisplayText organization, Asn1EncodableVector noticeNumbers)
		{
			this.organization = organization;
			this.noticeNumbers = new DerSequence(noticeNumbers);
		}

		private NoticeReference(Asn1Sequence seq)
		{
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			if (seq.Count != 2)
			{
				throw new ArgumentException(string.Concat((object)"Bad sequence size: ", (object)seq.Count), "seq");
			}
			organization = DisplayText.GetInstance(seq[0]);
			noticeNumbers = Asn1Sequence.GetInstance(seq[1]);
		}

		public static NoticeReference GetInstance(object obj)
		{
			if (obj is NoticeReference)
			{
				return (NoticeReference)obj;
			}
			if (obj == null)
			{
				return null;
			}
			return new NoticeReference(Asn1Sequence.GetInstance(obj));
		}

		public virtual DerInteger[] GetNoticeNumbers()
		{
			DerInteger[] array = new DerInteger[noticeNumbers.Count];
			for (int i = 0; i != noticeNumbers.Count; i++)
			{
				array[i] = DerInteger.GetInstance(noticeNumbers[i]);
			}
			return array;
		}

		public override Asn1Object ToAsn1Object()
		{
			return new DerSequence(organization, noticeNumbers);
		}
	}
}
