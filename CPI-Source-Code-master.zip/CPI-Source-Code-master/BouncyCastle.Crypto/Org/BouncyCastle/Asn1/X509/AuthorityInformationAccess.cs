using System;
using System.Text;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1.X509
{
	public class AuthorityInformationAccess : Asn1Encodable
	{
		private readonly AccessDescription[] descriptions;

		public static AuthorityInformationAccess GetInstance(object obj)
		{
			if (obj is AuthorityInformationAccess)
			{
				return (AuthorityInformationAccess)obj;
			}
			if (obj == null)
			{
				return null;
			}
			return new AuthorityInformationAccess(Asn1Sequence.GetInstance(obj));
		}

		private AuthorityInformationAccess(Asn1Sequence seq)
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			if (seq.Count < 1)
			{
				throw new ArgumentException("sequence may not be empty");
			}
			descriptions = new AccessDescription[seq.Count];
			for (int i = 0; i < seq.Count; i++)
			{
				descriptions[i] = AccessDescription.GetInstance(seq[i]);
			}
		}

		public AuthorityInformationAccess(AccessDescription description)
		{
			descriptions = new AccessDescription[1] { description };
		}

		public AuthorityInformationAccess(DerObjectIdentifier oid, GeneralName location)
			: this(new AccessDescription(oid, location))
		{
		}

		public AccessDescription[] GetAccessDescriptions()
		{
			return (AccessDescription[])((global::System.Array)descriptions).Clone();
		}

		public override Asn1Object ToAsn1Object()
		{
			return new DerSequence(descriptions);
		}

		public override string ToString()
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Expected O, but got Unknown
			StringBuilder val = new StringBuilder();
			string newLine = Platform.NewLine;
			val.Append("AuthorityInformationAccess:");
			val.Append(newLine);
			AccessDescription[] array = descriptions;
			foreach (AccessDescription accessDescription in array)
			{
				val.Append("    ");
				val.Append((object)accessDescription);
				val.Append(newLine);
			}
			return val.ToString();
		}
	}
}
