using System;
using System.Collections;
using System.IO;

namespace Org.BouncyCastle.Asn1
{
	public class BerSet : DerSet
	{
		public new static readonly BerSet Empty = new BerSet();

		public new static BerSet FromVector(Asn1EncodableVector v)
		{
			if (v.Count >= 1)
			{
				return new BerSet(v);
			}
			return Empty;
		}

		internal new static BerSet FromVector(Asn1EncodableVector v, bool needsSorting)
		{
			if (v.Count >= 1)
			{
				return new BerSet(v, needsSorting);
			}
			return Empty;
		}

		public BerSet()
		{
		}

		public BerSet(Asn1Encodable obj)
			: base(obj)
		{
		}

		public BerSet(Asn1EncodableVector v)
			: base(v, needsSorting: false)
		{
		}

		internal BerSet(Asn1EncodableVector v, bool needsSorting)
			: base(v, needsSorting)
		{
		}

		internal override void Encode(DerOutputStream derOut)
		{
			if (derOut is Asn1OutputStream || derOut is BerOutputStream)
			{
				((Stream)derOut).WriteByte((byte)49);
				((Stream)derOut).WriteByte((byte)128);
				{
					global::System.Collections.IEnumerator enumerator = GetEnumerator();
					try
					{
						while (enumerator.MoveNext())
						{
							Asn1Encodable obj = (Asn1Encodable)enumerator.get_Current();
							derOut.WriteObject(obj);
						}
					}
					finally
					{
						global::System.IDisposable disposable = enumerator as global::System.IDisposable;
						if (disposable != null)
						{
							disposable.Dispose();
						}
					}
				}
				((Stream)derOut).WriteByte((byte)0);
				((Stream)derOut).WriteByte((byte)0);
			}
			else
			{
				base.Encode(derOut);
			}
		}
	}
}
