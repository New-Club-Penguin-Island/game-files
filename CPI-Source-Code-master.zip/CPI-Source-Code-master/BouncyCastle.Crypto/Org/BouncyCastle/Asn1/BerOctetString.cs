using System;
using System.Collections;
using System.IO;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1
{
	public class BerOctetString : DerOctetString, global::System.Collections.IEnumerable
	{
		private const int MaxLength = 1000;

		private readonly global::System.Collections.IEnumerable octs;

		public static BerOctetString FromSequence(Asn1Sequence seq)
		{
			global::System.Collections.IList list = Platform.CreateArrayList();
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1Encodable asn1Encodable = (Asn1Encodable)enumerator.get_Current();
					list.Add((object)asn1Encodable);
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			return new BerOctetString((global::System.Collections.IEnumerable)list);
		}

		private static byte[] ToBytes(global::System.Collections.IEnumerable octs)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Expected O, but got Unknown
			MemoryStream val = new MemoryStream();
			global::System.Collections.IEnumerator enumerator = octs.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					DerOctetString derOctetString = (DerOctetString)enumerator.get_Current();
					byte[] octets = derOctetString.GetOctets();
					((Stream)val).Write(octets, 0, octets.Length);
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
			return val.ToArray();
		}

		public BerOctetString(byte[] str)
			: base(str)
		{
		}

		public BerOctetString(global::System.Collections.IEnumerable octets)
			: base(ToBytes(octets))
		{
			octs = octets;
		}

		public BerOctetString(Asn1Object obj)
			: base(obj)
		{
		}

		public BerOctetString(Asn1Encodable obj)
			: base(obj.ToAsn1Object())
		{
		}

		public override byte[] GetOctets()
		{
			return str;
		}

		public global::System.Collections.IEnumerator GetEnumerator()
		{
			if (octs == null)
			{
				return ((global::System.Collections.IEnumerable)GenerateOcts()).GetEnumerator();
			}
			return octs.GetEnumerator();
		}

		[Obsolete("Use GetEnumerator() instead")]
		public global::System.Collections.IEnumerator GetObjects()
		{
			return GetEnumerator();
		}

		private global::System.Collections.IList GenerateOcts()
		{
			global::System.Collections.IList list = Platform.CreateArrayList();
			for (int i = 0; i < str.Length; i += 1000)
			{
				int num = Math.Min(str.Length, i + 1000);
				byte[] array = new byte[num - i];
				global::System.Array.Copy((global::System.Array)str, i, (global::System.Array)array, 0, array.Length);
				list.Add((object)new DerOctetString(array));
			}
			return list;
		}

		internal override void Encode(DerOutputStream derOut)
		{
			if (derOut is Asn1OutputStream || derOut is BerOutputStream)
			{
				((Stream)derOut).WriteByte((byte)36);
				((Stream)derOut).WriteByte((byte)128);
				{
					global::System.Collections.IEnumerator enumerator = GetEnumerator();
					try
					{
						while (enumerator.MoveNext())
						{
							DerOctetString obj = (DerOctetString)enumerator.get_Current();
							derOut.WriteObject(obj);
						}
					}
					finally
					{
						global::System.IDisposable disposable = enumerator as global::System.IDisposable;
						if (disposable != null)
						{
							disposable.Dispose();
						}
					}
				}
				((Stream)derOut).WriteByte((byte)0);
				((Stream)derOut).WriteByte((byte)0);
			}
			else
			{
				base.Encode(derOut);
			}
		}
	}
}
