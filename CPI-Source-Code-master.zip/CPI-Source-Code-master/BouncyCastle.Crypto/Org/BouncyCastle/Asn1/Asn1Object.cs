using System;
using System.IO;

namespace Org.BouncyCastle.Asn1
{
	public abstract class Asn1Object : Asn1Encodable
	{
		public static Asn1Object FromByteArray(byte[] data)
		{
			//IL_0002: Unknown result type (might be due to invalid IL or missing references)
			//IL_0008: Expected O, but got Unknown
			//IL_002c: Unknown result type (might be due to invalid IL or missing references)
			//IL_003c: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				MemoryStream val = new MemoryStream(data, false);
				Asn1InputStream asn1InputStream = new Asn1InputStream((Stream)(object)val, data.Length);
				Asn1Object result = asn1InputStream.ReadObject();
				if (((Stream)val).get_Position() != ((Stream)val).get_Length())
				{
					throw new IOException("extra data found after object");
				}
				return result;
			}
			catch (InvalidCastException)
			{
				throw new IOException("cannot recognise object in byte array");
			}
		}

		public static Asn1Object FromStream(Stream inStr)
		{
			//IL_0014: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				return new Asn1InputStream(inStr).ReadObject();
			}
			catch (InvalidCastException)
			{
				throw new IOException("cannot recognise object in stream");
			}
		}

		public sealed override Asn1Object ToAsn1Object()
		{
			return this;
		}

		internal abstract void Encode(DerOutputStream derOut);

		protected abstract bool Asn1Equals(Asn1Object asn1Object);

		protected abstract int Asn1GetHashCode();

		internal bool CallAsn1Equals(Asn1Object obj)
		{
			return Asn1Equals(obj);
		}

		internal int CallAsn1GetHashCode()
		{
			return Asn1GetHashCode();
		}
	}
}
