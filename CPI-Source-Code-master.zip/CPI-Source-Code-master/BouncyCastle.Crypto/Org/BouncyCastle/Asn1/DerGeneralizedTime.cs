using System;
using System.Globalization;
using System.Text;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1
{
	public class DerGeneralizedTime : Asn1Object
	{
		private readonly string time;

		public string TimeString => time;

		private bool HasFractionalSeconds => time.IndexOf('.') == 14;

		public static DerGeneralizedTime GetInstance(object obj)
		{
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is DerGeneralizedTime)
			{
				return (DerGeneralizedTime)obj;
			}
			throw new ArgumentException("illegal object in GetInstance: " + Platform.GetTypeName(obj), "obj");
		}

		public static DerGeneralizedTime GetInstance(Asn1TaggedObject obj, bool isExplicit)
		{
			Asn1Object @object = obj.GetObject();
			if (isExplicit || @object is DerGeneralizedTime)
			{
				return GetInstance(@object);
			}
			return new DerGeneralizedTime(((Asn1OctetString)@object).GetOctets());
		}

		public DerGeneralizedTime(string time)
		{
			//IL_0017: Expected O, but got Unknown
			//IL_0027: Unknown result type (might be due to invalid IL or missing references)
			this.time = time;
			try
			{
				ToDateTime();
			}
			catch (FormatException val)
			{
				FormatException val2 = val;
				throw new ArgumentException("invalid date string: " + ((global::System.Exception)(object)val2).get_Message());
			}
		}

		public DerGeneralizedTime(global::System.DateTime time)
		{
			this.time = time.ToString("yyyyMMddHHmmss\\Z");
		}

		internal DerGeneralizedTime(byte[] bytes)
		{
			time = Strings.FromAsciiByteArray(bytes);
		}

		public string GetTime()
		{
			if (time.get_Chars(time.get_Length() - 1) == 'Z')
			{
				return time.Substring(0, time.get_Length() - 1) + "GMT+00:00";
			}
			int num = time.get_Length() - 5;
			char c = time.get_Chars(num);
			if (c == '-' || c == '+')
			{
				return string.Concat(new string[5]
				{
					time.Substring(0, num),
					"GMT",
					time.Substring(num, 3),
					":",
					time.Substring(num + 3)
				});
			}
			num = time.get_Length() - 3;
			c = time.get_Chars(num);
			if (c == '-' || c == '+')
			{
				return time.Substring(0, num) + "GMT" + time.Substring(num) + ":00";
			}
			return time + CalculateGmtOffset();
		}

		private string CalculateGmtOffset()
		{
			//IL_0010: Unknown result type (might be due to invalid IL or missing references)
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			//IL_0018: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			char c = '+';
			global::System.DateTime dateTime = ToDateTime();
			TimeSpan val = TimeZone.get_CurrentTimeZone().GetUtcOffset(dateTime);
			if (((TimeSpan)(ref val)).CompareTo((object)TimeSpan.Zero) < 0)
			{
				c = '-';
				val = ((TimeSpan)(ref val)).Duration();
			}
			int hours = ((TimeSpan)(ref val)).get_Hours();
			int minutes = ((TimeSpan)(ref val)).get_Minutes();
			return string.Concat(new object[5]
			{
				"GMT",
				c,
				Convert(hours),
				":",
				Convert(minutes)
			});
		}

		private static string Convert(int time)
		{
			if (time < 10)
			{
				return string.Concat((object)"0", (object)time);
			}
			return time.ToString();
		}

		public global::System.DateTime ToDateTime()
		{
			string text = time;
			bool makeUniversal = false;
			string format;
			if (Platform.EndsWith(text, "Z"))
			{
				if (HasFractionalSeconds)
				{
					int count = text.get_Length() - text.IndexOf('.') - 2;
					format = "yyyyMMddHHmmss." + FString(count) + "\\Z";
				}
				else
				{
					format = "yyyyMMddHHmmss\\Z";
				}
			}
			else if (time.IndexOf('-') > 0 || time.IndexOf('+') > 0)
			{
				text = GetTime();
				makeUniversal = true;
				if (HasFractionalSeconds)
				{
					int count2 = Platform.IndexOf(text, "GMT") - 1 - text.IndexOf('.');
					format = "yyyyMMddHHmmss." + FString(count2) + "'GMT'zzz";
				}
				else
				{
					format = "yyyyMMddHHmmss'GMT'zzz";
				}
			}
			else if (HasFractionalSeconds)
			{
				int count3 = text.get_Length() - 1 - text.IndexOf('.');
				format = "yyyyMMddHHmmss." + FString(count3);
			}
			else
			{
				format = "yyyyMMddHHmmss";
			}
			return ParseDateString(text, format, makeUniversal);
		}

		private string FString(int count)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0006: Expected O, but got Unknown
			StringBuilder val = new StringBuilder();
			for (int i = 0; i < count; i++)
			{
				val.Append('f');
			}
			return val.ToString();
		}

		private global::System.DateTime ParseDateString(string s, string format, bool makeUniversal)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0033: Unknown result type (might be due to invalid IL or missing references)
			//IL_003b: Unknown result type (might be due to invalid IL or missing references)
			DateTimeStyles val = (DateTimeStyles)0;
			if (Platform.EndsWith(format, "Z"))
			{
				try
				{
					val = (DateTimeStyles)Enums.GetEnumValue(typeof(DateTimeStyles), "AssumeUniversal");
				}
				catch (global::System.Exception)
				{
				}
				val = (DateTimeStyles)(val | 0x10);
			}
			global::System.DateTime result = global::System.DateTime.ParseExact(s, format, (IFormatProvider)(object)DateTimeFormatInfo.get_InvariantInfo(), val);
			if (!makeUniversal)
			{
				return result;
			}
			return result.ToUniversalTime();
		}

		private byte[] GetOctets()
		{
			return Strings.ToAsciiByteArray(time);
		}

		internal override void Encode(DerOutputStream derOut)
		{
			derOut.WriteEncoded(24, GetOctets());
		}

		protected override bool Asn1Equals(Asn1Object asn1Object)
		{
			DerGeneralizedTime derGeneralizedTime = asn1Object as DerGeneralizedTime;
			if (derGeneralizedTime == null)
			{
				return false;
			}
			return time.Equals(derGeneralizedTime.time);
		}

		protected override int Asn1GetHashCode()
		{
			return time.GetHashCode();
		}
	}
}
