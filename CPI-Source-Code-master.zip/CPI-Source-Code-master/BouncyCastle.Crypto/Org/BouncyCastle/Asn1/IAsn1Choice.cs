namespace Org.BouncyCastle.Asn1
{
	public interface IAsn1Choice
	{
	}
}
