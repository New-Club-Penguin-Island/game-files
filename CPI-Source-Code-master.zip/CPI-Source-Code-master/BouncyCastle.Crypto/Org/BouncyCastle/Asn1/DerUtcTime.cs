using System;
using System.Globalization;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1
{
	public class DerUtcTime : Asn1Object
	{
		private readonly string time;

		public string TimeString
		{
			get
			{
				if (time.IndexOf('-') < 0 && time.IndexOf('+') < 0)
				{
					if (time.get_Length() == 11)
					{
						return time.Substring(0, 10) + "00GMT+00:00";
					}
					return time.Substring(0, 12) + "GMT+00:00";
				}
				int num = time.IndexOf('-');
				if (num < 0)
				{
					num = time.IndexOf('+');
				}
				string text = time;
				if (num == time.get_Length() - 3)
				{
					text += "00";
				}
				if (num == 10)
				{
					return string.Concat(new string[5]
					{
						text.Substring(0, 10),
						"00GMT",
						text.Substring(10, 3),
						":",
						text.Substring(13, 2)
					});
				}
				return string.Concat(new string[5]
				{
					text.Substring(0, 12),
					"GMT",
					text.Substring(12, 3),
					":",
					text.Substring(15, 2)
				});
			}
		}

		[Obsolete("Use 'AdjustedTimeString' property instead")]
		public string AdjustedTime => AdjustedTimeString;

		public string AdjustedTimeString
		{
			get
			{
				string timeString = TimeString;
				string text = ((timeString.get_Chars(0) < '5') ? "20" : "19");
				return text + timeString;
			}
		}

		public static DerUtcTime GetInstance(object obj)
		{
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is DerUtcTime)
			{
				return (DerUtcTime)obj;
			}
			throw new ArgumentException("illegal object in GetInstance: " + Platform.GetTypeName(obj));
		}

		public static DerUtcTime GetInstance(Asn1TaggedObject obj, bool isExplicit)
		{
			Asn1Object @object = obj.GetObject();
			if (isExplicit || @object is DerUtcTime)
			{
				return GetInstance(@object);
			}
			return new DerUtcTime(((Asn1OctetString)@object).GetOctets());
		}

		public DerUtcTime(string time)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			//IL_0025: Expected O, but got Unknown
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			if (time == null)
			{
				throw new ArgumentNullException("time");
			}
			this.time = time;
			try
			{
				ToDateTime();
			}
			catch (FormatException val)
			{
				FormatException val2 = val;
				throw new ArgumentException("invalid date string: " + ((global::System.Exception)(object)val2).get_Message());
			}
		}

		public DerUtcTime(global::System.DateTime time)
		{
			this.time = time.ToString("yyMMddHHmmss", (IFormatProvider)(object)CultureInfo.get_InvariantCulture()) + "Z";
		}

		internal DerUtcTime(byte[] bytes)
		{
			time = Strings.FromAsciiByteArray(bytes);
		}

		public global::System.DateTime ToDateTime()
		{
			return ParseDateString(TimeString, "yyMMddHHmmss'GMT'zzz");
		}

		public global::System.DateTime ToAdjustedDateTime()
		{
			return ParseDateString(AdjustedTimeString, "yyyyMMddHHmmss'GMT'zzz");
		}

		private global::System.DateTime ParseDateString(string dateStr, string formatStr)
		{
			return global::System.DateTime.ParseExact(dateStr, formatStr, (IFormatProvider)(object)DateTimeFormatInfo.get_InvariantInfo()).ToUniversalTime();
		}

		private byte[] GetOctets()
		{
			return Strings.ToAsciiByteArray(time);
		}

		internal override void Encode(DerOutputStream derOut)
		{
			derOut.WriteEncoded(23, GetOctets());
		}

		protected override bool Asn1Equals(Asn1Object asn1Object)
		{
			DerUtcTime derUtcTime = asn1Object as DerUtcTime;
			if (derUtcTime == null)
			{
				return false;
			}
			return time.Equals(derUtcTime.time);
		}

		protected override int Asn1GetHashCode()
		{
			return time.GetHashCode();
		}

		public override string ToString()
		{
			return time;
		}
	}
}
