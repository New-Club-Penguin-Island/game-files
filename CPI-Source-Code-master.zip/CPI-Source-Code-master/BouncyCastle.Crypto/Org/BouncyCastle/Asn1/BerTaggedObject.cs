using System;
using System.Collections;
using System.IO;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1
{
	public class BerTaggedObject : DerTaggedObject
	{
		public BerTaggedObject(int tagNo, Asn1Encodable obj)
			: base(tagNo, obj)
		{
		}

		public BerTaggedObject(bool explicitly, int tagNo, Asn1Encodable obj)
			: base(explicitly, tagNo, obj)
		{
		}

		public BerTaggedObject(int tagNo)
			: base(explicitly: false, tagNo, BerSequence.Empty)
		{
		}

		internal override void Encode(DerOutputStream derOut)
		{
			if (derOut is Asn1OutputStream || derOut is BerOutputStream)
			{
				derOut.WriteTag(160, tagNo);
				((Stream)derOut).WriteByte((byte)128);
				if (!IsEmpty())
				{
					if (!explicitly)
					{
						global::System.Collections.IEnumerable enumerable;
						if (obj is Asn1OctetString)
						{
							if (obj is BerOctetString)
							{
								enumerable = (BerOctetString)obj;
							}
							else
							{
								Asn1OctetString asn1OctetString = (Asn1OctetString)obj;
								enumerable = new BerOctetString(asn1OctetString.GetOctets());
							}
						}
						else if (obj is Asn1Sequence)
						{
							enumerable = (Asn1Sequence)obj;
						}
						else
						{
							if (!(obj is Asn1Set))
							{
								throw Platform.CreateNotImplementedException(Platform.GetTypeName(obj));
							}
							enumerable = (Asn1Set)obj;
						}
						{
							global::System.Collections.IEnumerator enumerator = enumerable.GetEnumerator();
							try
							{
								while (enumerator.MoveNext())
								{
									Asn1Encodable asn1Encodable = (Asn1Encodable)enumerator.get_Current();
									derOut.WriteObject(asn1Encodable);
								}
							}
							finally
							{
								global::System.IDisposable disposable = enumerator as global::System.IDisposable;
								if (disposable != null)
								{
									disposable.Dispose();
								}
							}
						}
					}
					else
					{
						derOut.WriteObject(obj);
					}
				}
				((Stream)derOut).WriteByte((byte)0);
				((Stream)derOut).WriteByte((byte)0);
			}
			else
			{
				base.Encode(derOut);
			}
		}
	}
}
