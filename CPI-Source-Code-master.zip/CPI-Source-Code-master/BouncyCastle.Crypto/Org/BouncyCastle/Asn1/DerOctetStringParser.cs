using System;
using System.IO;

namespace Org.BouncyCastle.Asn1
{
	public class DerOctetStringParser : Asn1OctetStringParser, IAsn1Convertible
	{
		private readonly DefiniteLengthInputStream stream;

		internal DerOctetStringParser(DefiniteLengthInputStream stream)
		{
			this.stream = stream;
		}

		public Stream GetOctetStream()
		{
			return (Stream)(object)stream;
		}

		public Asn1Object ToAsn1Object()
		{
			//IL_0014: Expected O, but got Unknown
			//IL_0025: Unknown result type (might be due to invalid IL or missing references)
			try
			{
				return new DerOctetString(stream.ToArray());
			}
			catch (IOException val)
			{
				IOException val2 = val;
				throw new InvalidOperationException("IOException converting stream to byte array: " + ((global::System.Exception)(object)val2).get_Message(), (global::System.Exception)(object)val2);
			}
		}
	}
}
