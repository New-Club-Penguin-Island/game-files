using System;
using System.Runtime.CompilerServices;
using System.Text;
using Org.BouncyCastle.Utilities;

namespace Org.BouncyCastle.Asn1
{
	public class DerUniversalString : DerStringBase
	{
		private static readonly char[] table;

		private readonly byte[] str;

		public static DerUniversalString GetInstance(object obj)
		{
			//IL_0022: Unknown result type (might be due to invalid IL or missing references)
			if (obj == null || obj is DerUniversalString)
			{
				return (DerUniversalString)obj;
			}
			throw new ArgumentException("illegal object in GetInstance: " + Platform.GetTypeName(obj));
		}

		public static DerUniversalString GetInstance(Asn1TaggedObject obj, bool isExplicit)
		{
			Asn1Object @object = obj.GetObject();
			if (isExplicit || @object is DerUniversalString)
			{
				return GetInstance(@object);
			}
			return new DerUniversalString(Asn1OctetString.GetInstance(@object).GetOctets());
		}

		public DerUniversalString(byte[] str)
		{
			//IL_000e: Unknown result type (might be due to invalid IL or missing references)
			if (str == null)
			{
				throw new ArgumentNullException("str");
			}
			this.str = str;
		}

		public override string GetString()
		{
			//IL_0005: Unknown result type (might be due to invalid IL or missing references)
			//IL_000b: Expected O, but got Unknown
			StringBuilder val = new StringBuilder("#");
			byte[] derEncoded = GetDerEncoded();
			for (int i = 0; i != derEncoded.Length; i++)
			{
				uint num = derEncoded[i];
				val.Append(table[(num >> 4) & 0xF]);
				val.Append(table[derEncoded[i] & 0xF]);
			}
			return val.ToString();
		}

		public byte[] GetOctets()
		{
			return (byte[])((global::System.Array)str).Clone();
		}

		internal override void Encode(DerOutputStream derOut)
		{
			derOut.WriteEncoded(28, str);
		}

		protected override bool Asn1Equals(Asn1Object asn1Object)
		{
			DerUniversalString derUniversalString = asn1Object as DerUniversalString;
			if (derUniversalString == null)
			{
				return false;
			}
			return Arrays.AreEqual(str, derUniversalString.str);
		}

		static DerUniversalString()
		{
			char[] array = new char[16];
			RuntimeHelpers.InitializeArray((global::System.Array)array, (RuntimeFieldHandle)/*OpCode not supported: LdMemberToken*/);
			table = array;
		}
	}
}
