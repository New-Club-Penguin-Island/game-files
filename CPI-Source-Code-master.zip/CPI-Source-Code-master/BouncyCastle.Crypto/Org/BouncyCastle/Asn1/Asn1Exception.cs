using System;
using System.IO;

namespace Org.BouncyCastle.Asn1
{
	[Serializable]
	public class Asn1Exception : IOException
	{
		public Asn1Exception()
			: this()
		{
		}

		public Asn1Exception(string message)
			: this(message)
		{
		}

		public Asn1Exception(string message, global::System.Exception exception)
			: this(message, exception)
		{
		}
	}
}
