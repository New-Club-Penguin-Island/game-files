using System;
using System.Collections;

namespace Org.BouncyCastle.Asn1.Ocsp
{
	public class CrlID : Asn1Encodable
	{
		private readonly DerIA5String crlUrl;

		private readonly DerInteger crlNum;

		private readonly DerGeneralizedTime crlTime;

		public DerIA5String CrlUrl => crlUrl;

		public DerInteger CrlNum => crlNum;

		public DerGeneralizedTime CrlTime => crlTime;

		public CrlID(Asn1Sequence seq)
		{
			//IL_0078: Unknown result type (might be due to invalid IL or missing references)
			global::System.Collections.IEnumerator enumerator = seq.GetEnumerator();
			try
			{
				while (enumerator.MoveNext())
				{
					Asn1TaggedObject asn1TaggedObject = (Asn1TaggedObject)enumerator.get_Current();
					switch (asn1TaggedObject.TagNo)
					{
					case 0:
						crlUrl = DerIA5String.GetInstance(asn1TaggedObject, isExplicit: true);
						break;
					case 1:
						crlNum = DerInteger.GetInstance(asn1TaggedObject, isExplicit: true);
						break;
					case 2:
						crlTime = DerGeneralizedTime.GetInstance(asn1TaggedObject, isExplicit: true);
						break;
					default:
						throw new ArgumentException(string.Concat((object)"unknown tag number: ", (object)asn1TaggedObject.TagNo));
					}
				}
			}
			finally
			{
				global::System.IDisposable disposable = enumerator as global::System.IDisposable;
				if (disposable != null)
				{
					disposable.Dispose();
				}
			}
		}

		public override Asn1Object ToAsn1Object()
		{
			Asn1EncodableVector asn1EncodableVector = new Asn1EncodableVector();
			if (crlUrl != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: true, 0, crlUrl));
			}
			if (crlNum != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: true, 1, crlNum));
			}
			if (crlTime != null)
			{
				asn1EncodableVector.Add(new DerTaggedObject(explicitly: true, 2, crlTime));
			}
			return new DerSequence(asn1EncodableVector);
		}
	}
}
