using System;
using System.Collections.Generic;
using UnityEngine;

namespace ClubPenguin
{
	public class ImportedProperties : MonoBehaviour
	{
		[Serializable]
		public struct StringProperty
		{
			public string Key;

			public string Value;

			public StringProperty(string key, object value)
			{
				Key = key;
				Value = (string)value;
			}
		}

		[Serializable]
		public struct FloatProperty
		{
			public string Key;

			public float Value;

			public FloatProperty(string key, object value)
			{
				Key = key;
				Value = (float)value;
			}
		}

		[Serializable]
		public struct ColorProperty
		{
			public string Key;

			public Color Value;

			public ColorProperty(string key, object value)
			{
				Key = key;
				Value = new Color(((Vector4)value).x, ((Vector4)value).y, ((Vector4)value).z);
			}
		}

		[Serializable]
		public struct BooleanProperty
		{
			public string Key;

			public bool Value;

			public BooleanProperty(string key, object value)
			{
				Key = key;
				Value = (bool)value;
			}
		}

		public List<StringProperty> Strings;

		public List<FloatProperty> Floats;

		public List<ColorProperty> Colors;

		public List<BooleanProperty> Booleans;

		public void Parse(string[] keys, object[] values)
		{
			Strings = new List<StringProperty>();
			Floats = new List<FloatProperty>();
			Colors = new List<ColorProperty>();
			Booleans = new List<BooleanProperty>();
			for (int i = 0; i < keys.Length; i++)
			{
				string text = keys[i];
				object obj = values[i];
				Type type = obj.GetType();
				if (type == typeof(string))
				{
					Strings.Add(new StringProperty(text, obj));
					continue;
				}
				if (type == typeof(float))
				{
					Floats.Add(new FloatProperty(text, obj));
					continue;
				}
				if (type == typeof(bool))
				{
					Booleans.Add(new BooleanProperty(text, obj));
					continue;
				}
				if (type == typeof(Vector4))
				{
					Colors.Add(new ColorProperty(text, obj));
					continue;
				}
				throw new UnityException($"Imported property {text} has invalid type {type}. Value: {obj}!");
			}
		}
	}
}
