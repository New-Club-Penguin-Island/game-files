namespace ClubPenguin.Avatar
{
	public enum EquipmentPartType
	{
		BaseMeshReplacement,
		BaseMeshAddition,
		SecondaryMeshAddition
	}
}
