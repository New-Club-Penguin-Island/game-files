using System;

namespace ClubPenguin.Avatar
{
	[Serializable]
	public class AvatarSlot
	{
		public string Name;

		public BodyViewDefinition[] LOD;
	}
}
