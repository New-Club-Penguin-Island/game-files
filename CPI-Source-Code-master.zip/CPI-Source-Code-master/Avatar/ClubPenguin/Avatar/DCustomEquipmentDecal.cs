using System;

namespace ClubPenguin.Avatar
{
	[Serializable]
	public struct DCustomEquipmentDecal
	{
		public EquipmentDecalType Type;

		public string TextureName;

		public int DefinitionId;

		public int Index;

		public float Scale;

		public float Uoffset;

		public float Voffset;

		public float Rotation;

		public bool Repeat;

		public override string ToString()
		{
			return $"[DCustomEquipmentDecal] DefinitionId: {DefinitionId} Name: {TextureName} Type: {Type} Full hash: {GetFullHash():x8} Resource hash: {GetResourceHash():x8}";
		}

		public int GetResourceHash()
		{
			StructHash structHash = default(StructHash);
			structHash.Combine(TextureName ?? string.Empty);
			return structHash;
		}

		public int GetFullHash()
		{
			StructHash structHash = default(StructHash);
			structHash.Combine(Type);
			structHash.Combine(TextureName ?? string.Empty);
			structHash.Combine(DefinitionId);
			structHash.Combine(Index);
			structHash.Combine(Scale);
			structHash.Combine(Uoffset);
			structHash.Combine(Voffset);
			structHash.Combine(Rotation);
			structHash.Combine(Repeat);
			return structHash;
		}

		public bool Validate()
		{
			bool flag = true;
			flag &= !string.IsNullOrEmpty(TextureName);
			return flag & (DefinitionId != 0);
		}
	}
}
