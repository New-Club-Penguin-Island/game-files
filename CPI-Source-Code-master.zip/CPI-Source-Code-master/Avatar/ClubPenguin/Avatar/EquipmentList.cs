using UnityEngine;

namespace ClubPenguin.Avatar
{
	public class EquipmentList : ScriptableObject
	{
		public EquipmentModelDefinition[] Equipment = new EquipmentModelDefinition[0];
	}
}
