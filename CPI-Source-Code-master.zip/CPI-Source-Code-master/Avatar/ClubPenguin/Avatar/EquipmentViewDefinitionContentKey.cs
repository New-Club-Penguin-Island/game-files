using System;
using Disney.Kelowna.Common;

namespace ClubPenguin.Avatar
{
	[Serializable]
	public class EquipmentViewDefinitionContentKey : TypedAssetContentKey<EquipmentViewDefinition>
	{
		public EquipmentViewDefinitionContentKey()
		{
		}

		public EquipmentViewDefinitionContentKey(string key)
			: base(key)
		{
		}

		public EquipmentViewDefinitionContentKey(AssetContentKey key, params string[] args)
			: base(key, args)
		{
		}
	}
}
