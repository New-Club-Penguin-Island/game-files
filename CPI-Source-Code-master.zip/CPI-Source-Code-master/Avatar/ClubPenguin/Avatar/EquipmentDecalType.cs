namespace ClubPenguin.Avatar
{
	public enum EquipmentDecalType
	{
		DECAL,
		FABRIC
	}
}
