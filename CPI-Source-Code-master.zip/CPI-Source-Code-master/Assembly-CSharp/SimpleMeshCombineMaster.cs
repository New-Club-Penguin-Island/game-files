using UnityEngine;

public class SimpleMeshCombineMaster : MonoBehaviour
{
	public bool generateLightmapUV;
}
